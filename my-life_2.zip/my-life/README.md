# MY LIFE

Organizador personal para Android con perfiles privados (PIN), tareas, calendario, objetivos, hábitos, notas, finanzas en ARS, estadísticas y notificaciones locales.

- React Native + Expo SDK 54 + TypeScript
- Base de datos local SQLite (`expo-sqlite`), sin servidores
- PIN con PBKDF2-SHA256 + sal en `expo-secure-store` (Android Keystore)
- Notificaciones locales con `expo-notifications`

## Compilar

La forma prevista es GitHub Actions (`.github/workflows/compilar.yml`): instala las dependencias nativas con `npx expo install` (así quedan en las versiones exactas del SDK 54), corre las pruebas, genera el proyecto Android y publica `MyLife.apk` como Release. Ver `INSTRUCCIONES.txt`.

En una computadora, el equivalente es:

```
npm install
npx expo install react react-native react-native-svg react-native-safe-area-context react-native-screens expo-sqlite expo-notifications expo-secure-store expo-local-authentication expo-crypto expo-file-system expo-sharing expo-document-picker expo-linear-gradient expo-haptics expo-status-bar expo-splash-screen expo-system-ui expo-font expo-constants expo-intent-launcher @expo-google-fonts/inter @react-native-community/datetimepicker expo-background-task expo-task-manager
npm test
npx expo prebuild --platform android
cd android && ./gradlew assembleRelease
```

## Estructura

- `src/lib` utilidades puras (fechas, dinero, criptografía, texto)
- `src/logic` reglas (rachas, repeticiones del calendario, finanzas, estadísticas, plan de notificaciones)
- `src/db` esquema, migraciones, repositorios por perfil y copias de seguridad
- `src/security` PIN, recuperación y bloqueo por intentos
- `src/notifications` programación de avisos en Android
- `src/screens` pantallas; `src/ui` componentes de diseño
- `tests` pruebas automáticas (`npm test`)
