// Interpretación de frases en español (rioplatense) para el amigo personal.
// Sin IA ni internet: reglas y patrones. Tolera errores de tipeo comunes gracias a normalizeText (sin acentos, minúsculas).

import { normalizeText } from '../lib/text';
import { addDays, isValidTime, minutesToTime, toISODate, WEEKDAYS_LONG } from '../lib/dates';
import { parseAmount } from '../lib/money';
import type { DollarCasa } from '../types';

export type Period = 'today' | 'yesterday' | 'week' | 'month' | 'lastMonth';

export type Intent =
  | { type: 'greet' }
  | { type: 'thanks' }
  | { type: 'help' }
  | { type: 'who' }
  | { type: 'summary'; period: Period }
  | { type: 'spending'; period: Period; category: string | null }
  | { type: 'income'; period: Period }
  | { type: 'balance' }
  | { type: 'pending'; date: string; label: string }
  | { type: 'goals' }
  | { type: 'habits' }
  | { type: 'dollar'; casa: DollarCasa | null }
  | { type: 'subscriptions'; name: string | null }
  | { type: 'countdown'; name: string | null }
  | { type: 'routine' }
  | { type: 'add_expense'; amount: number; name: string; date: string }
  | { type: 'add_income'; amount: number; name: string; date: string }
  | { type: 'add_task'; title: string; date: string | null; time: string | null }
  | { type: 'add_reminder'; title: string; date: string; time: string | null }
  | { type: 'add_note'; text: string }
  | { type: 'rename'; name: string }
  | { type: 'personality'; value: 'warm' | 'direct' | 'fun' }
  | { type: 'clear' }
  | { type: 'unknown'; text: string };

export interface ParseCtx {
  today: string; // YYYY-MM-DD
}

const has = (t: string, ...words: string[]) => words.some((w) => t.includes(w));
const re = (t: string, r: RegExp) => r.test(t);

/** Fecha mencionada en la frase. Devuelve ISO y el texto sin esa parte. */
export function extractDate(t: string, ctx: ParseCtx): { date: string | null; rest: string; label: string } {
  let rest = t;
  let date: string | null = null;
  let label = '';
  const rules: [RegExp, (m: RegExpMatchArray) => string, string][] = [
    [/\bpasado manana\b/, () => addDays(ctx.today, 2), 'pasado mañana'],
    [/\bmanana\b/, () => addDays(ctx.today, 1), 'mañana'],
    [/\bhoy\b/, () => ctx.today, 'hoy'],
    [/\bayer\b/, () => addDays(ctx.today, -1), 'ayer'],
    [/\b(?:el |este |el proximo |proximo )?(lunes|martes|miercoles|jueves|viernes|sabado|domingo)\b/, (m) => nextWeekday(ctx.today, m[1]), ''],
    [/\b(?:el )?(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/, (m) => fromDMY(ctx.today, m[1], m[2], m[3]), ''],
    [/\b(?:el )?(\d{1,2}) de (enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)\b/, (m) => fromDayMonth(ctx.today, m[1], m[2]), ''],
  ];
  for (const [r, fn, lbl] of rules) {
    const m = rest.match(r);
    if (m) {
      date = fn(m);
      label = lbl || m[0].replace(/^(el|este|proximo|el proximo) /, '');
      rest = rest.replace(r, ' ');
      break;
    }
  }
  return { date, rest: rest.replace(/\s+/g, ' ').trim(), label };
}

function nextWeekday(today: string, name: string): string {
  const idx = WEEKDAYS_LONG.map((w) => normalizeText(w)).indexOf(name);
  const cur = new Date(today.replace(/-/g, '/')).getDay();
  let diff = (idx - cur + 7) % 7;
  if (diff === 0) diff = 7;
  return addDays(today, diff);
}

function fromDMY(today: string, d: string, m: string, y?: string): string {
  const year = y ? (y.length === 2 ? 2000 + Number(y) : Number(y)) : Number(today.slice(0, 4));
  const iso = `${year}-${String(Number(m)).padStart(2, '0')}-${String(Number(d)).padStart(2, '0')}`;
  return iso;
}

function fromDayMonth(today: string, d: string, month: string): string {
  const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
  const mi = months.indexOf(month === 'setiembre' ? 'septiembre' : month);
  let year = Number(today.slice(0, 4));
  const iso = `${year}-${String(mi + 1).padStart(2, '0')}-${String(Number(d)).padStart(2, '0')}`;
  if (iso < today) year++;
  return `${year}-${String(mi + 1).padStart(2, '0')}-${String(Number(d)).padStart(2, '0')}`;
}

/** Hora mencionada: "a las 10", "10:30", "10hs", "a la 1", "8 de la noche". */
export function extractTime(t: string): { time: string | null; rest: string } {
  const m = t.match(/\b(?:a las?|a la|las?)\s*(\d{1,2})(?:[:.h](\d{2}))?\s*(hs|h|horas)?\s*(de la manana|de la tarde|de la noche|am|pm)?\b/) ?? t.match(/\b(\d{1,2}):(\d{2})\s*(hs|h)?\s*(de la manana|de la tarde|de la noche|am|pm)?\b/);
  if (!m) return { time: null, rest: t };
  let h = Number(m[1]);
  const min = m[2] ? Number(m[2]) : 0;
  const mod = m[4] ?? '';
  if ((mod === 'de la tarde' || mod === 'de la noche' || mod === 'pm') && h < 12) h += 12;
  if ((mod === 'de la manana' || mod === 'am') && h === 12) h = 0;
  if (h > 23 || min > 59) return { time: null, rest: t };
  const time = minutesToTime(h * 60 + min);
  return { time: isValidTime(time) ? time : null, rest: t.replace(m[0], ' ').replace(/\s+/g, ' ').trim() };
}

/** Monto: "3500", "3.500", "$3500", "3500 pesos", "3500$", "2 lucas" (mil), "1,5k". */
export function extractAmount(t: string): { cents: number | null; rest: string } {
  let m = t.match(/\$?\s*(\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:[.,]\d{1,2})?)\s*(k|lucas?|mil|pesos|\$|mangos)?\b/);
  if (!m) return { cents: null, rest: t };
  let cents = parseAmount(m[1]);
  if (cents == null) return { cents: null, rest: t };
  const unit = m[2] ?? '';
  if (unit === 'k' || unit === 'luca' || unit === 'lucas' || unit === 'mil') cents *= 1000;
  return { cents, rest: t.replace(m[0], ' ').replace(/\s+/g, ' ').trim() };
}

function period(t: string): Period {
  if (has(t, 'ayer')) return 'yesterday';
  if (has(t, 'mes pasado', 'el mes anterior')) return 'lastMonth';
  if (has(t, 'semana')) return 'week';
  if (has(t, 'mes')) return 'month';
  return 'today';
}

const CASAS: [RegExp, DollarCasa][] = [
  [/\bblue\b/, 'blue'], [/\boficial\b/, 'oficial'], [/\bmep\b|\bbolsa\b/, 'bolsa'], [/\bccl\b|contado con liqui/, 'contadoconliqui'],
  [/\btarjeta\b/, 'tarjeta'], [/\bmayorista\b/, 'mayorista'], [/\bcripto\b/, 'cripto'],
];

const CATEGORY_WORDS: Record<string, string[]> = {
  Comida: ['comida', 'super', 'supermercado', 'almuerzo', 'cena', 'desayuno', 'delivery', 'pizza', 'hamburguesa', 'kiosco', 'panaderia', 'verduleria', 'carniceria'],
  Transporte: ['transporte', 'colectivo', 'bondi', 'sube', 'uber', 'taxi', 'nafta', 'tren', 'subte', 'remis'],
  Salidas: ['salida', 'salidas', 'boliche', 'bar', 'cine', 'birra', 'cerveza', 'joda', 'fiesta'],
  Salud: ['salud', 'farmacia', 'medico', 'remedio', 'remedios', 'dentista'],
  Estudio: ['estudio', 'facultad', 'colegio', 'curso', 'libro', 'fotocopias', 'apuntes'],
  Ropa: ['ropa', 'zapatillas', 'remera', 'pantalon', 'campera'],
  Casa: ['casa', 'alquiler', 'luz', 'gas', 'agua', 'internet', 'expensas'],
  Juegos: ['juego', 'juegos', 'videojuego', 'steam', 'play', 'skin'],
  Suscripciones: ['suscripcion', 'netflix', 'spotify', 'streaming'],
  Regalos: ['regalo', 'regalos', 'cumple'],
};

export function guessCategory(text: string): string | null {
  const t = normalizeText(text);
  for (const [cat, words] of Object.entries(CATEGORY_WORDS)) if (words.some((w) => re(t, new RegExp(`\\b${w}\\b`)))) return cat;
  return null;
}

function cleanName(s: string): string {
  return s
    .replace(/\b(gaste|gasté|pague|pagué|compre|compré|me gaste|anota|anotá|anotame|registra|registrá|agrega|agregá|un gasto de|gasto de|gasto|en el|en la|en los|en las|en|de|por|para|el|la|los|las|un|una|hoy|ayer|manana|pesos|\$)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Recupera acentos y mayúsculas de las palabras originales (el análisis se hace sin acentos). */
function restoreAccents(name: string, raw: string): string {
  const originals = raw.split(/\s+/).filter(Boolean);
  return name
    .split(' ')
    .map((w) => originals.find((o) => normalizeText(o.replace(/[^A-Za-z0-9\u00C0-\u024F]/g, '')) === w) ?.replace(/[^A-Za-z0-9\u00C0-\u024F]/g, '') ?? w)
    .join(' ');
}

function capitalizeFirst(s: string): string {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

export function parseIntent(raw: string, ctx: ParseCtx): Intent {
  const text = (raw || '').trim();
  const t = normalizeText(text);
  if (!t) return { type: 'unknown', text };

  // Configuración del amigo
  let m = t.match(/\b(?:llamate|te llamas|tu nombre es|te voy a llamar|quiero que te llames)\s+([a-z0-9]+)\b/);
  if (m) return { type: 'rename', name: capitalizeFirst(m[1]).slice(0, 20) };
  if (re(t, /\b(se|sé) mas (directo|directa|serio|seria|corto)\b|\bmodo directo\b/)) return { type: 'personality', value: 'direct' };
  if (re(t, /\b(se|sé) mas (divertido|divertida|gracioso|graciosa|chistoso)\b|\bmodo divertido\b/)) return { type: 'personality', value: 'fun' };
  if (re(t, /\b(se|sé) mas (calido|calida|amable|cariñoso|carinoso)\b|\bmodo calido\b/)) return { type: 'personality', value: 'warm' };
  if (re(t, /\b(borra|borrá|limpia|limpiá|elimina|eliminá) (el|la|todo el|nuestro)? ?(chat|historial|conversacion)\b/)) return { type: 'clear' };

  if (re(t, /^(hola|buenas|buen dia|buenos dias|buenas tardes|buenas noches|hey|holis|que tal|como estas|como andas|todo bien)\b/) && t.length < 40) return { type: 'greet' };
  if (re(t, /^(gracias|genial|perfecto|dale|joya|buenisimo|ok|oka|listo)\b/) && t.length < 30) return { type: 'thanks' };
  if (re(t, /\b(ayuda|que podes hacer|que sabes hacer|que haces|como funcionas|opciones|comandos)\b/)) return { type: 'help' };
  if (re(t, /\b(quien sos|que sos|sos una ia|sos un robot|sos humano)\b/)) return { type: 'who' };

  // Anotar cosas
  const amt = extractAmount(t);
  if (amt.cents && re(t, /\b(gaste|pague|compre|me sali|se me fue|anota .*gasto|gasto)\b/)) {
    const d = extractDate(amt.rest, ctx);
    const name = cleanName(d.rest) || 'Gasto';
    return { type: 'add_expense', amount: amt.cents, name: capitalizeFirst(restoreAccents(name, text)), date: d.date ?? ctx.today };
  }
  if (amt.cents && re(t, /\b(cobre|gane|me pagaron|ingreso|me dieron|entro|entraron)\b/)) {
    const d = extractDate(amt.rest, ctx);
    const name = cleanName(d.rest.replace(/\b(cobre|gane|me pagaron|ingreso|me dieron|entro|entraron)\b/g, ' ')) || 'Ingreso';
    return { type: 'add_income', amount: amt.cents, name: capitalizeFirst(restoreAccents(name, text)), date: d.date ?? ctx.today };
  }
  m = t.match(/\b(?:recordame|recuerdame|acordame|avisame|hazme acordar|haceme acordar)\s+(?:que\s+|de\s+)?(.+)$/);
  if (m) {
    const tm = extractTime(m[1]);
    const d = extractDate(tm.rest, ctx);
    const title = capitalizeFirst(restoreAccents(d.rest.replace(/^(que|de|tengo que|debo)\s+/, '').trim(), text)) || 'Recordatorio';
    return { type: 'add_reminder', title, date: d.date ?? (tm.time ? ctx.today : addDays(ctx.today, 1)), time: tm.time };
  }
  m = t.match(/\b(?:agrega|agregá|anota|anotá|anotame|crea|creá|nueva?)\s+(?:una\s+)?tarea\s*:?\s*(.+)$/) ?? t.match(/\b(?:tengo que|tengo q|debo|hay que)\s+(.+)$/);
  if (m) {
    const tm = extractTime(m[1]);
    const d = extractDate(tm.rest, ctx);
    const title = capitalizeFirst(restoreAccents(d.rest.trim(), text));
    if (title.length > 1) return { type: 'add_task', title, date: d.date, time: tm.time };
  }
  m = t.match(/\b(?:anota|anotá|anotame|guarda|guardá|nota)\s*:?\s+(.+)$/);
  if (m && !amt.cents) return { type: 'add_note', text: capitalizeFirst(restoreAccents(m[1].trim(), text)) };

  // Consultas
  if (re(t, /\b(dolar|dólar|blue|mep|ccl)\b/) && !re(t, /\b(meta|ahorr)/)) {
    const casa = CASAS.find(([r]) => r.test(t))?.[1] ?? null;
    return { type: 'dollar', casa };
  }
  if (re(t, /\b(saldo|plata tengo|cuanta plata|cuanto tengo|balance|dinero tengo)\b/)) return { type: 'balance' };
  if (re(t, /\b(gaste|gastado|gastos|gasto|cuanto se me fue|en que gaste|cuanto llevo gastado)\b/)) {
    const cat = Object.keys(CATEGORY_WORDS).find((c) => CATEGORY_WORDS[c].some((w) => re(t, new RegExp(`\\b${w}\\b`)))) ?? null;
    return { type: 'spending', period: period(t), category: cat };
  }
  if (re(t, /\b(gane|ingresos|ingrese|cobre|entro plata|cuanto cobre)\b/)) return { type: 'income', period: period(t) };
  if (re(t, /\b(suscripcion|suscripciones|cuanto (me )?falta para pagar|cuando se cobra|cuando pago|proximo cobro|cobros)\b/)) {
    const mm = t.match(/\b(?:pagar|cobra|cobro de|de)\s+([a-z0-9 ]{2,30})$/);
    return { type: 'subscriptions', name: mm ? mm[1].trim() : null };
  }
  if (re(t, /\b(cuanto falta|cuantos dias faltan|falta mucho|cuenta regresiva)\b/)) {
    const mm = t.match(/\b(?:para|pa)\s+(?:el |la |mi )?([a-z0-9 ]{2,40})$/);
    return { type: 'countdown', name: mm ? mm[1].trim() : null };
  }
  if (re(t, /\b(rutina|que sigue|que me toca|proximo paso)\b/)) return { type: 'routine' };
  if (re(t, /\b(objetivo|objetivos|metas|meta|como voy|progreso)\b/)) return { type: 'goals' };
  if (re(t, /\b(habito|habitos|racha|rachas)\b/)) return { type: 'habits' };
  if (re(t, /\b(pendiente|pendientes|que tengo|que hay|agenda|tareas|eventos|que me espera|que toca)\b/)) {
    const d = extractDate(t, ctx);
    const date = d.date ?? ctx.today;
    const label = d.label || (date === ctx.today ? 'hoy' : d.label);
    return { type: 'pending', date, label };
  }
  if (re(t, /\b(que hice|como me fue|resumen|como estuvo|como vengo|como va|como fue)\b/)) return { type: 'summary', period: period(t) };

  return { type: 'unknown', text };
}

export const QUICK_PROMPTS = ['¿Qué hice hoy?', '¿Cuánto gasté esta semana?', 'Pendientes de mañana', '¿A cuánto está el dólar?', '¿Cómo voy con mis objetivos?', 'Gasté 3500 en el súper'];

export { toISODate };
