// Tarea en segundo plano (expo-background-task + expo-task-manager):
// cada tanto actualiza el dólar (y dispara alertas) y trae novedades de Descubrir.
//
// Limitaciones reales de Android: el intervalo mínimo es de 15 minutos, el sistema decide
// cuándo corre (puede demorar bastante en algunos fabricantes) y si el usuario "mata" la app
// desde recientes, se detiene hasta que la vuelva a abrir. Por eso la app también revisa
// todo cada vez que se abre.
//
// Los módulos se cargan con require() dentro de try/catch: si faltaran, la app sigue
// funcionando sin segundo plano.

import { profilesRepo } from '../db/repos';
import { openExpoDb } from '../db/expoDb';
import { migrate, setDb, getDb } from '../db/db';
import { refreshDollar } from '../services/dollarService';
import { notifyDollarHits } from '../notifications/notifications';
import { refreshDiscover } from '../services/discoverService';

export const TASK_NAME = 'mylife-refresh';
const INTERVAL_MINUTES = 60;

let BackgroundTask: any = null;
let TaskManager: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  BackgroundTask = require('expo-background-task');
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  TaskManager = require('expo-task-manager');
} catch {
  BackgroundTask = null;
  TaskManager = null;
}

export function backgroundAvailable(): boolean {
  return !!BackgroundTask && !!TaskManager;
}

async function ensureDb() {
  try {
    getDb();
  } catch {
    const db = await openExpoDb();
    await migrate(db);
    setDb(db);
  }
}

/** Lo que hace la tarea. También se usa al abrir la app. */
export async function runRefresh(): Promise<{ dollar: boolean; discover: number }> {
  await ensureDb();
  const profiles = await profilesRepo.list();
  const anyDollar = profiles.some((p) => p.settings.modules.dollar);
  let dollarOk = false;
  if (anyDollar) {
    try {
      const r = await refreshDollar();
      dollarOk = r.ok;
      if (r.hits.length) await notifyDollarHits(r.hits);
    } catch {}
  }
  let discover = 0;
  for (const p of profiles) {
    if (!p.settings.modules.discover || !p.settings.discover.topics.length) continue;
    // "Solo con Wi-Fi": en segundo plano no podemos saber la red con certeza, así que no usamos datos.
    if (p.settings.discover.wifiOnly) continue;
    try {
      const r = await refreshDiscover(p.id);
      discover += r.added;
    } catch {}
  }
  return { dollar: dollarOk, discover };
}

// La tarea se define al importar este archivo (tiene que estar en el ámbito global).
if (TaskManager && BackgroundTask) {
  try {
    TaskManager.defineTask(TASK_NAME, async () => {
      try {
        await runRefresh();
        return BackgroundTask.BackgroundTaskResult?.Success ?? 1;
      } catch {
        return BackgroundTask.BackgroundTaskResult?.Failed ?? 2;
      }
    });
  } catch (e) {
    console.warn('No se pudo definir la tarea en segundo plano', e);
  }
}

/** Registra la tarea periódica (si está disponible). Se puede llamar varias veces. */
export async function registerBackgroundRefresh(): Promise<boolean> {
  if (!backgroundAvailable()) return false;
  try {
    const status = await BackgroundTask.getStatusAsync?.();
    if (status != null && BackgroundTask.BackgroundTaskStatus && status === BackgroundTask.BackgroundTaskStatus.Restricted) return false;
    const already = await TaskManager.isTaskRegisteredAsync?.(TASK_NAME);
    if (!already) await BackgroundTask.registerTaskAsync(TASK_NAME, { minimumInterval: INTERVAL_MINUTES });
    return true;
  } catch (e) {
    console.warn('No se pudo registrar la tarea en segundo plano', e);
    return false;
  }
}
