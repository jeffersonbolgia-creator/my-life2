// Repositorios: todas las consultas filtran por profile_id, de modo que
// cada perfil sólo puede leer y modificar sus propios datos.

import { getDb, nowStamp } from './db';
import { mergeSettings } from './defaults';
import type {
  AssistantMessage, CalendarEvent, Countdown, DiscoverItem, DollarAlert, DollarCasa, DollarRate, Goal, Habit, Note, NoteItem, Profile, ProfileAnswers, ProfileSettings,
  Reminder, Routine, RoutineLog, RoutineStep, Subscription, Task, Transaction,
} from '../types';

/** Tablas con profile_id (en orden de borrado). Las tablas hijas sin profile_id se borran aparte. */
export const PROFILE_TABLES = ['tasks', 'events', 'goals', 'habits', 'notes', 'transactions', 'reminders', 'countdowns', 'routines', 'dollar_alerts', 'subscriptions', 'discover_items', 'assistant_messages'] as const;

const bool = (v: unknown) => v === 1 || v === true || v === '1';
const parseJSON = <T>(s: unknown, fallback: T): T => {
  if (typeof s !== 'string' || !s) return fallback;
  try {
    return JSON.parse(s) as T;
  } catch {
    return fallback;
  }
};
const numList = (s: unknown): number[] =>
  typeof s === 'string' && s ? s.split(',').map(Number).filter((n) => Number.isInteger(n) && n >= 0 && n <= 6) : [];
const listStr = (a: number[]) => [...new Set(a)].sort().join(',');

// ---------- Perfiles ----------

function mapProfile(r: any): Profile {
  return {
    id: r.id,
    name: r.name,
    birthDate: r.birth_date ?? null,
    age: r.age ?? null,
    avatarColor: r.avatar_color,
    answers: parseJSON<ProfileAnswers>(r.answers, {}),
    settings: mergeSettings(parseJSON<Partial<ProfileSettings>>(r.settings, {})),
    securityQuestion: r.security_question ?? '',
    createdAt: r.created_at,
  };
}

export const profilesRepo = {
  async list(): Promise<Profile[]> {
    return (await getDb().all('SELECT * FROM profiles ORDER BY id')).map(mapProfile);
  },
  async get(id: number): Promise<Profile | null> {
    const r = await getDb().first('SELECT * FROM profiles WHERE id = ?', [id]);
    return r ? mapProfile(r) : null;
  },
  async create(p: Omit<Profile, 'id' | 'createdAt'>): Promise<number> {
    const r = await getDb().run(
      'INSERT INTO profiles (name, birth_date, age, avatar_color, answers, settings, security_question, created_at) VALUES (?,?,?,?,?,?,?,?)',
      [p.name, p.birthDate, p.age, p.avatarColor, JSON.stringify(p.answers), JSON.stringify(p.settings), p.securityQuestion, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(id: number, p: Partial<Omit<Profile, 'id' | 'createdAt'>>): Promise<void> {
    const cur = await this.get(id);
    if (!cur) return;
    const n = { ...cur, ...p };
    await getDb().run(
      'UPDATE profiles SET name=?, birth_date=?, age=?, avatar_color=?, answers=?, settings=?, security_question=? WHERE id=?',
      [n.name, n.birthDate, n.age, n.avatarColor, JSON.stringify(n.answers), JSON.stringify(n.settings), n.securityQuestion, id],
    );
  },
  async updateSettings(id: number, patch: Partial<ProfileSettings>): Promise<ProfileSettings | null> {
    const cur = await this.get(id);
    if (!cur) return null;
    const settings = mergeSettings({ ...cur.settings, ...patch });
    await getDb().run('UPDATE profiles SET settings=? WHERE id=?', [JSON.stringify(settings), id]);
    return settings;
  },
  async remove(id: number): Promise<void> {
    const db = getDb();
    await db.transaction(async () => {
      await db.run('DELETE FROM habit_logs WHERE habit_id IN (SELECT id FROM habits WHERE profile_id = ?)', [id]);
      await db.run('DELETE FROM routine_logs WHERE routine_id IN (SELECT id FROM routines WHERE profile_id = ?)', [id]);
      for (const t of PROFILE_TABLES) {
        await db.run(`DELETE FROM ${t} WHERE profile_id = ?`, [id]);
      }
      await db.run('DELETE FROM profiles WHERE id = ?', [id]);
    });
  },
};

// ---------- Tareas ----------

function mapTask(r: any): Task {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    description: r.description ?? '',
    dueDate: r.due_date ?? null,
    dueTime: r.due_time ?? null,
    priority: (r.priority ?? 1) as Task['priority'],
    category: r.category ?? '',
    remindMinutes: r.remind_minutes ?? null,
    completedAt: r.completed_at ?? null,
    createdAt: r.created_at,
  };
}

export type TaskInput = Omit<Task, 'id' | 'profileId' | 'createdAt' | 'completedAt'>;

export const tasksRepo = {
  async list(pid: number): Promise<Task[]> {
    return (await getDb().all(
      `SELECT * FROM tasks WHERE profile_id = ?
       ORDER BY completed_at IS NOT NULL, due_date IS NULL, due_date, due_time IS NULL, due_time, priority DESC, id DESC`,
      [pid],
    )).map(mapTask);
  },
  async get(pid: number, id: number): Promise<Task | null> {
    const r = await getDb().first('SELECT * FROM tasks WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapTask(r) : null;
  },
  async create(pid: number, t: TaskInput): Promise<number> {
    const r = await getDb().run(
      'INSERT INTO tasks (profile_id, title, description, due_date, due_time, priority, category, remind_minutes, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, t.title, t.description, t.dueDate, t.dueTime, t.priority, t.category, t.remindMinutes, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, t: TaskInput): Promise<void> {
    await getDb().run(
      'UPDATE tasks SET title=?, description=?, due_date=?, due_time=?, priority=?, category=?, remind_minutes=? WHERE id=? AND profile_id=?',
      [t.title, t.description, t.dueDate, t.dueTime, t.priority, t.category, t.remindMinutes, id, pid],
    );
  },
  async setCompleted(pid: number, id: number, done: boolean): Promise<void> {
    await getDb().run('UPDATE tasks SET completed_at=? WHERE id=? AND profile_id=?', [done ? nowStamp() : null, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM tasks WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Eventos ----------

function mapEvent(r: any): CalendarEvent {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    type: r.type,
    date: r.date,
    startTime: r.start_time ?? null,
    endTime: r.end_time ?? null,
    allDay: bool(r.all_day),
    recurrence: r.recurrence,
    weekdays: numList(r.weekdays),
    untilDate: r.until_date ?? null,
    remindMinutes: r.remind_minutes ?? null,
    location: r.location ?? '',
    notes: r.notes ?? '',
    createdAt: r.created_at,
  };
}

export type EventInput = Omit<CalendarEvent, 'id' | 'profileId' | 'createdAt'>;

export const eventsRepo = {
  async list(pid: number): Promise<CalendarEvent[]> {
    return (await getDb().all('SELECT * FROM events WHERE profile_id = ? ORDER BY date, start_time', [pid])).map(mapEvent);
  },
  async get(pid: number, id: number): Promise<CalendarEvent | null> {
    const r = await getDb().first('SELECT * FROM events WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapEvent(r) : null;
  },
  async create(pid: number, e: EventInput): Promise<number> {
    const r = await getDb().run(
      `INSERT INTO events (profile_id, title, type, date, start_time, end_time, all_day, recurrence, weekdays, until_date, remind_minutes, location, notes, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [pid, e.title, e.type, e.date, e.startTime, e.endTime, e.allDay ? 1 : 0, e.recurrence, listStr(e.weekdays), e.untilDate, e.remindMinutes, e.location, e.notes, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, e: EventInput): Promise<void> {
    await getDb().run(
      `UPDATE events SET title=?, type=?, date=?, start_time=?, end_time=?, all_day=?, recurrence=?, weekdays=?, until_date=?, remind_minutes=?, location=?, notes=?
       WHERE id=? AND profile_id=?`,
      [e.title, e.type, e.date, e.startTime, e.endTime, e.allDay ? 1 : 0, e.recurrence, listStr(e.weekdays), e.untilDate, e.remindMinutes, e.location, e.notes, id, pid],
    );
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM events WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Objetivos ----------

function mapGoal(r: any): Goal {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    description: r.description ?? '',
    term: r.term,
    targetDate: r.target_date ?? null,
    progress: r.progress ?? 0,
    completedAt: r.completed_at ?? null,
    createdAt: r.created_at,
    savingTarget: r.saving_target ?? null,
    savingSaved: Number(r.saving_saved ?? 0),
    savingCurrency: r.saving_currency === 'USD' ? 'USD' : 'ARS',
    savingCasa: r.saving_casa ?? null,
  };
}

export type GoalInput = Omit<Goal, 'id' | 'profileId' | 'createdAt' | 'completedAt' | 'savingTarget' | 'savingSaved' | 'savingCurrency' | 'savingCasa'> &
  Partial<Pick<Goal, 'savingTarget' | 'savingSaved' | 'savingCurrency' | 'savingCasa'>>;

/** Si es meta de ahorro, el progreso sale de lo ahorrado sobre el objetivo. */
export function goalProgress(g: Pick<GoalInput, 'progress' | 'savingTarget' | 'savingSaved'>): number {
  if (g.savingTarget && g.savingTarget > 0) return Math.max(0, Math.min(100, Math.round(((g.savingSaved ?? 0) / g.savingTarget) * 100)));
  return Math.max(0, Math.min(100, Math.round(g.progress)));
}

export const goalsRepo = {
  async list(pid: number): Promise<Goal[]> {
    return (await getDb().all(
      'SELECT * FROM goals WHERE profile_id = ? ORDER BY completed_at IS NOT NULL, target_date IS NULL, target_date, id DESC',
      [pid],
    )).map(mapGoal);
  },
  async get(pid: number, id: number): Promise<Goal | null> {
    const r = await getDb().first('SELECT * FROM goals WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapGoal(r) : null;
  },
  async create(pid: number, g: GoalInput): Promise<number> {
    const progress = goalProgress(g);
    const r = await getDb().run(
      'INSERT INTO goals (profile_id, title, description, term, target_date, progress, completed_at, created_at, saving_target, saving_saved, saving_currency, saving_casa) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      [pid, g.title, g.description, g.term, g.targetDate, progress, progress >= 100 ? nowStamp() : null, nowStamp(), g.savingTarget ?? null, Math.round(g.savingSaved ?? 0), g.savingCurrency ?? 'ARS', g.savingCasa ?? null],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, g: GoalInput): Promise<void> {
    const cur = await this.get(pid, id);
    if (!cur) return;
    const progress = goalProgress(g);
    const completedAt = progress >= 100 ? cur.completedAt ?? nowStamp() : null;
    await getDb().run(
      'UPDATE goals SET title=?, description=?, term=?, target_date=?, progress=?, completed_at=?, saving_target=?, saving_saved=?, saving_currency=?, saving_casa=? WHERE id=? AND profile_id=?',
      [g.title, g.description, g.term, g.targetDate, progress, completedAt, g.savingTarget ?? null, Math.round(g.savingSaved ?? 0), g.savingCurrency ?? 'ARS', g.savingCasa ?? null, id, pid],
    );
  },
  async setProgress(pid: number, id: number, progress: number): Promise<void> {
    const cur = await this.get(pid, id);
    if (!cur) return;
    await this.update(pid, id, { ...cur, progress });
  },
  /** Suma (o resta) ahorro a una meta de ahorro. */
  async addSaving(pid: number, id: number, deltaCents: number): Promise<void> {
    const cur = await this.get(pid, id);
    if (!cur || !cur.savingTarget) return;
    await this.update(pid, id, { ...cur, savingSaved: Math.max(0, cur.savingSaved + Math.round(deltaCents)) });
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM goals WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Hábitos ----------

function mapHabit(r: any): Habit {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    frequency: r.frequency,
    weekdays: numList(r.weekdays),
    targetPerWeek: r.target_per_week ?? 3,
    reminderTime: r.reminder_time ?? null,
    color: r.color,
    icon: r.icon,
    archived: bool(r.archived),
    createdAt: r.created_at,
  };
}

export type HabitInput = Omit<Habit, 'id' | 'profileId' | 'createdAt' | 'archived'>;

export const habitsRepo = {
  async list(pid: number, includeArchived = false): Promise<Habit[]> {
    return (await getDb().all(
      `SELECT * FROM habits WHERE profile_id = ? ${includeArchived ? '' : 'AND archived = 0'} ORDER BY archived, id`,
      [pid],
    )).map(mapHabit);
  },
  async get(pid: number, id: number): Promise<Habit | null> {
    const r = await getDb().first('SELECT * FROM habits WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapHabit(r) : null;
  },
  async create(pid: number, h: HabitInput): Promise<number> {
    const r = await getDb().run(
      'INSERT INTO habits (profile_id, title, frequency, weekdays, target_per_week, reminder_time, color, icon, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, h.title, h.frequency, listStr(h.weekdays), h.targetPerWeek, h.reminderTime, h.color, h.icon, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, h: HabitInput): Promise<void> {
    await getDb().run(
      'UPDATE habits SET title=?, frequency=?, weekdays=?, target_per_week=?, reminder_time=?, color=?, icon=? WHERE id=? AND profile_id=?',
      [h.title, h.frequency, listStr(h.weekdays), h.targetPerWeek, h.reminderTime, h.color, h.icon, id, pid],
    );
  },
  async setArchived(pid: number, id: number, archived: boolean): Promise<void> {
    await getDb().run('UPDATE habits SET archived=? WHERE id=? AND profile_id=?', [archived ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    const db = getDb();
    const own = await db.first('SELECT id FROM habits WHERE id=? AND profile_id=?', [id, pid]);
    if (!own) return;
    await db.transaction(async () => {
      await db.run('DELETE FROM habit_logs WHERE habit_id=?', [id]);
      await db.run('DELETE FROM habits WHERE id=? AND profile_id=?', [id, pid]);
    });
  },
  async logs(pid: number): Promise<Map<number, Set<string>>> {
    const rows = await getDb().all<{ habit_id: number; date: string }>(
      'SELECT l.habit_id, l.date FROM habit_logs l JOIN habits h ON h.id = l.habit_id WHERE h.profile_id = ?',
      [pid],
    );
    const map = new Map<number, Set<string>>();
    for (const r of rows) {
      if (!map.has(r.habit_id)) map.set(r.habit_id, new Set());
      map.get(r.habit_id)!.add(r.date);
    }
    return map;
  },
  async toggle(pid: number, habitId: number, date: string): Promise<boolean> {
    const db = getDb();
    const own = await db.first('SELECT id FROM habits WHERE id=? AND profile_id=?', [habitId, pid]);
    if (!own) return false;
    const exists = await db.first('SELECT 1 AS x FROM habit_logs WHERE habit_id=? AND date=?', [habitId, date]);
    if (exists) {
      await db.run('DELETE FROM habit_logs WHERE habit_id=? AND date=?', [habitId, date]);
      return false;
    }
    await db.run('INSERT INTO habit_logs (habit_id, date) VALUES (?,?)', [habitId, date]);
    return true;
  },
};

// ---------- Notas ----------

function mapNote(r: any): Note {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title ?? '',
    body: r.body ?? '',
    category: r.category ?? '',
    isList: bool(r.is_list),
    items: parseJSON<NoteItem[]>(r.items, []),
    favorite: bool(r.favorite),
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export type NoteInput = Pick<Note, 'title' | 'body' | 'category' | 'isList' | 'items' | 'favorite'>;

export const notesRepo = {
  async list(pid: number): Promise<Note[]> {
    return (await getDb().all('SELECT * FROM notes WHERE profile_id = ? ORDER BY favorite DESC, updated_at DESC', [pid])).map(mapNote);
  },
  async get(pid: number, id: number): Promise<Note | null> {
    const r = await getDb().first('SELECT * FROM notes WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapNote(r) : null;
  },
  async create(pid: number, n: NoteInput): Promise<number> {
    const now = nowStamp();
    const r = await getDb().run(
      'INSERT INTO notes (profile_id, title, body, category, is_list, items, favorite, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, n.title, n.body, n.category, n.isList ? 1 : 0, JSON.stringify(n.items), n.favorite ? 1 : 0, now, now],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, n: NoteInput): Promise<void> {
    await getDb().run(
      'UPDATE notes SET title=?, body=?, category=?, is_list=?, items=?, favorite=?, updated_at=? WHERE id=? AND profile_id=?',
      [n.title, n.body, n.category, n.isList ? 1 : 0, JSON.stringify(n.items), n.favorite ? 1 : 0, nowStamp(), id, pid],
    );
  },
  async setFavorite(pid: number, id: number, fav: boolean): Promise<void> {
    await getDb().run('UPDATE notes SET favorite=? WHERE id=? AND profile_id=?', [fav ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM notes WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Finanzas ----------

function mapTx(r: any): Transaction {
  return {
    id: r.id,
    profileId: r.profile_id,
    kind: r.kind,
    name: r.name,
    emoji: r.emoji ?? '',
    category: r.category ?? 'Otros',
    quantity: Number(r.quantity ?? 1),
    unitPrice: r.unit_price ?? null,
    amount: Number(r.amount),
    date: r.date,
    description: r.description ?? '',
    createdAt: r.created_at,
  };
}

export type TxInput = Omit<Transaction, 'id' | 'profileId' | 'createdAt'>;

function validateTx(t: TxInput) {
  if (!t.name.trim()) throw new Error('Falta el nombre');
  if (!Number.isFinite(t.amount) || t.amount <= 0) throw new Error('El importe debe ser mayor a cero');
}

export const financeRepo = {
  async list(pid: number): Promise<Transaction[]> {
    return (await getDb().all('SELECT * FROM transactions WHERE profile_id = ? ORDER BY date DESC, id DESC', [pid])).map(mapTx);
  },
  async get(pid: number, id: number): Promise<Transaction | null> {
    const r = await getDb().first('SELECT * FROM transactions WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapTx(r) : null;
  },
  async create(pid: number, t: TxInput): Promise<number> {
    validateTx(t);
    const r = await getDb().run(
      'INSERT INTO transactions (profile_id, kind, name, emoji, category, quantity, unit_price, amount, date, description, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
      [pid, t.kind, t.name.trim(), t.emoji, t.category, t.quantity, t.unitPrice, Math.round(t.amount), t.date, t.description, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, t: TxInput): Promise<void> {
    validateTx(t);
    await getDb().run(
      'UPDATE transactions SET kind=?, name=?, emoji=?, category=?, quantity=?, unit_price=?, amount=?, date=?, description=? WHERE id=? AND profile_id=?',
      [t.kind, t.name.trim(), t.emoji, t.category, t.quantity, t.unitPrice, Math.round(t.amount), t.date, t.description, id, pid],
    );
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM transactions WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Recordatorios ----------

function mapReminder(r: any): Reminder {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    kind: r.kind,
    date: r.date,
    time: r.time,
    repeat: r.repeat,
    amount: r.amount ?? null,
    notes: r.notes ?? '',
    done: bool(r.done),
    createdAt: r.created_at,
  };
}

export type ReminderInput = Omit<Reminder, 'id' | 'profileId' | 'createdAt' | 'done'>;

export const remindersRepo = {
  async list(pid: number): Promise<Reminder[]> {
    return (await getDb().all('SELECT * FROM reminders WHERE profile_id = ? ORDER BY done, date, time', [pid])).map(mapReminder);
  },
  async get(pid: number, id: number): Promise<Reminder | null> {
    const r = await getDb().first('SELECT * FROM reminders WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapReminder(r) : null;
  },
  async create(pid: number, r: ReminderInput): Promise<number> {
    const res = await getDb().run(
      'INSERT INTO reminders (profile_id, title, kind, date, time, repeat, amount, notes, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, r.title, r.kind, r.date, r.time, r.repeat, r.amount, r.notes, nowStamp()],
    );
    return res.lastInsertRowId;
  },
  async update(pid: number, id: number, r: ReminderInput): Promise<void> {
    await getDb().run(
      'UPDATE reminders SET title=?, kind=?, date=?, time=?, repeat=?, amount=?, notes=? WHERE id=? AND profile_id=?',
      [r.title, r.kind, r.date, r.time, r.repeat, r.amount, r.notes, id, pid],
    );
  },
  async setDone(pid: number, id: number, done: boolean): Promise<void> {
    await getDb().run('UPDATE reminders SET done=? WHERE id=? AND profile_id=?', [done ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM reminders WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Cuentas regresivas ----------

function mapCountdown(r: any): Countdown {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    date: r.date,
    time: r.time ?? null,
    icon: r.icon || 'Star',
    color: r.color || '#A78BFA',
    remindDaysBefore: r.remind_days_before ?? null,
    pinned: bool(r.pinned),
    createdAt: r.created_at,
  };
}

export type CountdownInput = Omit<Countdown, 'id' | 'profileId' | 'createdAt'>;

function validateCountdown(c: CountdownInput) {
  if (!c.title.trim()) throw new Error('Falta el título');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(c.date)) throw new Error('Falta la fecha');
}

export const countdownsRepo = {
  async list(pid: number): Promise<Countdown[]> {
    return (await getDb().all('SELECT * FROM countdowns WHERE profile_id = ? ORDER BY date, time IS NULL, time, id', [pid])).map(mapCountdown);
  },
  async get(pid: number, id: number): Promise<Countdown | null> {
    const r = await getDb().first('SELECT * FROM countdowns WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapCountdown(r) : null;
  },
  async create(pid: number, c: CountdownInput): Promise<number> {
    validateCountdown(c);
    const r = await getDb().run(
      'INSERT INTO countdowns (profile_id, title, date, time, icon, color, remind_days_before, pinned, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      [pid, c.title.trim(), c.date, c.time, c.icon, c.color, c.remindDaysBefore, c.pinned ? 1 : 0, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, c: CountdownInput): Promise<void> {
    validateCountdown(c);
    await getDb().run(
      'UPDATE countdowns SET title=?, date=?, time=?, icon=?, color=?, remind_days_before=?, pinned=? WHERE id=? AND profile_id=?',
      [c.title.trim(), c.date, c.time, c.icon, c.color, c.remindDaysBefore, c.pinned ? 1 : 0, id, pid],
    );
  },
  async setPinned(pid: number, id: number, pinned: boolean): Promise<void> {
    await getDb().run('UPDATE countdowns SET pinned=? WHERE id=? AND profile_id=?', [pinned ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM countdowns WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Rutinas ----------

function sanitizeSteps(raw: unknown): RoutineStep[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((s) => s && typeof s === 'object' && typeof (s as any).title === 'string')
    .map((s: any, i) => ({
      id: typeof s.id === 'string' && s.id ? s.id : `s${i + 1}`,
      title: String(s.title).trim(),
      minutes: Number.isFinite(Number(s.minutes)) ? Math.max(0, Math.round(Number(s.minutes))) : 0,
    }))
    .filter((s) => s.title);
}

function mapRoutine(r: any): Routine {
  return {
    id: r.id,
    profileId: r.profile_id,
    title: r.title,
    kind: r.kind === 'morning' || r.kind === 'night' ? r.kind : 'custom',
    icon: r.icon || 'Sunrise',
    color: r.color || '#FBBF24',
    startTime: r.start_time ?? null,
    steps: sanitizeSteps(parseJSON<unknown>(r.steps, [])),
    weekdays: numList(r.weekdays),
    remind: bool(r.remind),
    archived: bool(r.archived),
    createdAt: r.created_at,
  };
}

function mapRoutineLog(r: any): RoutineLog {
  const done = parseJSON<unknown>(r.done_steps, []);
  return {
    routineId: r.routine_id,
    date: r.date,
    doneSteps: Array.isArray(done) ? done.filter((x) => typeof x === 'string') : [],
    completed: bool(r.completed),
  };
}

export type RoutineInput = Omit<Routine, 'id' | 'profileId' | 'createdAt' | 'archived'>;

function validateRoutine(r: RoutineInput) {
  if (!r.title.trim()) throw new Error('Falta el nombre de la rutina');
  if (!sanitizeSteps(r.steps).length) throw new Error('Agregá al menos un paso');
}

export const routinesRepo = {
  async list(pid: number, includeArchived = false): Promise<Routine[]> {
    return (await getDb().all(
      `SELECT * FROM routines WHERE profile_id = ? ${includeArchived ? '' : 'AND archived = 0'} ORDER BY archived, start_time IS NULL, start_time, id`,
      [pid],
    )).map(mapRoutine);
  },
  async get(pid: number, id: number): Promise<Routine | null> {
    const r = await getDb().first('SELECT * FROM routines WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapRoutine(r) : null;
  },
  async create(pid: number, r: RoutineInput): Promise<number> {
    validateRoutine(r);
    const res = await getDb().run(
      'INSERT INTO routines (profile_id, title, kind, icon, color, start_time, steps, weekdays, remind, created_at) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [pid, r.title.trim(), r.kind, r.icon, r.color, r.startTime, JSON.stringify(sanitizeSteps(r.steps)), listStr(r.weekdays), r.remind ? 1 : 0, nowStamp()],
    );
    return res.lastInsertRowId;
  },
  async update(pid: number, id: number, r: RoutineInput): Promise<void> {
    validateRoutine(r);
    await getDb().run(
      'UPDATE routines SET title=?, kind=?, icon=?, color=?, start_time=?, steps=?, weekdays=?, remind=? WHERE id=? AND profile_id=?',
      [r.title.trim(), r.kind, r.icon, r.color, r.startTime, JSON.stringify(sanitizeSteps(r.steps)), listStr(r.weekdays), r.remind ? 1 : 0, id, pid],
    );
  },
  async setArchived(pid: number, id: number, archived: boolean): Promise<void> {
    await getDb().run('UPDATE routines SET archived=? WHERE id=? AND profile_id=?', [archived ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    const db = getDb();
    const own = await db.first('SELECT id FROM routines WHERE id=? AND profile_id=?', [id, pid]);
    if (!own) return;
    await db.transaction(async () => {
      await db.run('DELETE FROM routine_logs WHERE routine_id=?', [id]);
      await db.run('DELETE FROM routines WHERE id=? AND profile_id=?', [id, pid]);
    });
  },
  /** Registros de avance de todas las rutinas del perfil, por rutina y fecha. */
  async logs(pid: number): Promise<Map<number, Map<string, RoutineLog>>> {
    const rows = await getDb().all(
      'SELECT l.* FROM routine_logs l JOIN routines r ON r.id = l.routine_id WHERE r.profile_id = ?',
      [pid],
    );
    const map = new Map<number, Map<string, RoutineLog>>();
    for (const r of rows) {
      const log = mapRoutineLog(r);
      if (!map.has(log.routineId)) map.set(log.routineId, new Map());
      map.get(log.routineId)!.set(log.date, log);
    }
    return map;
  },
  async log(pid: number, routineId: number, date: string): Promise<RoutineLog | null> {
    const r = await getDb().first(
      'SELECT l.* FROM routine_logs l JOIN routines r ON r.id = l.routine_id WHERE r.profile_id = ? AND l.routine_id = ? AND l.date = ?',
      [pid, routineId, date],
    );
    return r ? mapRoutineLog(r) : null;
  },
  /** Marca o desmarca un paso de la rutina en un día. Devuelve el registro actualizado. */
  async toggleStep(pid: number, routineId: number, date: string, stepId: string): Promise<RoutineLog | null> {
    const db = getDb();
    const routine = await this.get(pid, routineId);
    if (!routine) return null;
    const cur = (await this.log(pid, routineId, date)) ?? { routineId, date, doneSteps: [], completed: false };
    const valid = new Set(routine.steps.map((s) => s.id));
    const done = new Set(cur.doneSteps.filter((s) => valid.has(s)));
    if (done.has(stepId)) done.delete(stepId);
    else if (valid.has(stepId)) done.add(stepId);
    const completed = routine.steps.length > 0 && routine.steps.every((s) => done.has(s.id));
    const next: RoutineLog = { routineId, date, doneSteps: [...done], completed };
    await db.run(
      'INSERT INTO routine_logs (routine_id, date, done_steps, completed) VALUES (?,?,?,?) ON CONFLICT(routine_id, date) DO UPDATE SET done_steps=excluded.done_steps, completed=excluded.completed',
      [routineId, date, JSON.stringify(next.doneSteps), completed ? 1 : 0],
    );
    return next;
  },
  /** Completa (o reinicia) todos los pasos de un día. */
  async setAll(pid: number, routineId: number, date: string, done: boolean): Promise<RoutineLog | null> {
    const routine = await this.get(pid, routineId);
    if (!routine) return null;
    const next: RoutineLog = { routineId, date, doneSteps: done ? routine.steps.map((s) => s.id) : [], completed: done && routine.steps.length > 0 };
    await getDb().run(
      'INSERT INTO routine_logs (routine_id, date, done_steps, completed) VALUES (?,?,?,?) ON CONFLICT(routine_id, date) DO UPDATE SET done_steps=excluded.done_steps, completed=excluded.completed',
      [routineId, date, JSON.stringify(next.doneSteps), next.completed ? 1 : 0],
    );
    return next;
  },
};


// ---------- Dólar ----------

export const DOLLAR_CASAS: DollarCasa[] = ['oficial', 'blue', 'bolsa', 'contadoconliqui', 'tarjeta', 'mayorista', 'cripto'];

function mapRate(r: any): DollarRate {
  return { casa: r.casa, date: r.date, buy: Number(r.buy), sell: Number(r.sell), updatedAt: r.updated_at };
}

export const dollarRepo = {
  /** Guarda o actualiza una cotización del día. */
  async upsert(rate: DollarRate): Promise<void> {
    await getDb().run(
      'INSERT INTO dollar_rates (casa, date, buy, sell, updated_at) VALUES (?,?,?,?,?) ON CONFLICT(casa, date) DO UPDATE SET buy=excluded.buy, sell=excluded.sell, updated_at=excluded.updated_at',
      [rate.casa, rate.date, rate.buy, rate.sell, rate.updatedAt],
    );
  },
  async upsertMany(rates: DollarRate[]): Promise<void> {
    const db = getDb();
    await db.transaction(async () => {
      for (const r of rates) await this.upsert(r);
    });
  },
  /** Última cotización de cada casa. */
  async latest(): Promise<DollarRate[]> {
    const rows = await getDb().all(
      'SELECT r.* FROM dollar_rates r JOIN (SELECT casa, MAX(date) AS d FROM dollar_rates GROUP BY casa) m ON m.casa = r.casa AND m.d = r.date',
    );
    return rows.map(mapRate);
  },
  async latestFor(casa: DollarCasa): Promise<DollarRate | null> {
    const r = await getDb().first('SELECT * FROM dollar_rates WHERE casa = ? ORDER BY date DESC LIMIT 1', [casa]);
    return r ? mapRate(r) : null;
  },
  /** Serie de una casa entre fechas (inclusive), ordenada por fecha. */
  async series(casa: DollarCasa, from: string, to: string): Promise<DollarRate[]> {
    return (await getDb().all('SELECT * FROM dollar_rates WHERE casa = ? AND date >= ? AND date <= ? ORDER BY date', [casa, from, to])).map(mapRate);
  },
  async count(casa: DollarCasa): Promise<number> {
    const r = await getDb().first<{ n: number }>('SELECT COUNT(*) AS n FROM dollar_rates WHERE casa = ?', [casa]);
    return r?.n ?? 0;
  },
  /** Borra cotizaciones más viejas que la fecha dada (para no acumular). */
  async prune(before: string): Promise<void> {
    await getDb().run('DELETE FROM dollar_rates WHERE date < ?', [before]);
  },
};

function mapAlert(r: any): DollarAlert {
  return {
    id: r.id, profileId: r.profile_id, casa: r.casa, kind: r.kind, value: Number(r.value), enabled: bool(r.enabled),
    lastFiredAt: r.last_fired_at ?? null, createdAt: r.created_at,
  };
}

export type DollarAlertInput = Pick<DollarAlert, 'casa' | 'kind' | 'value' | 'enabled'>;

export const dollarAlertsRepo = {
  async list(pid: number): Promise<DollarAlert[]> {
    return (await getDb().all('SELECT * FROM dollar_alerts WHERE profile_id = ? ORDER BY id', [pid])).map(mapAlert);
  },
  async listAll(): Promise<DollarAlert[]> {
    return (await getDb().all('SELECT * FROM dollar_alerts WHERE enabled = 1 ORDER BY profile_id, id')).map(mapAlert);
  },
  async create(pid: number, a: DollarAlertInput): Promise<number> {
    if (!Number.isFinite(a.value) || a.value <= 0) throw new Error('Ingresá un valor mayor a cero');
    const r = await getDb().run(
      'INSERT INTO dollar_alerts (profile_id, casa, kind, value, enabled, created_at) VALUES (?,?,?,?,?,?)',
      [pid, a.casa, a.kind, a.value, a.enabled ? 1 : 0, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, a: DollarAlertInput): Promise<void> {
    if (!Number.isFinite(a.value) || a.value <= 0) throw new Error('Ingresá un valor mayor a cero');
    await getDb().run('UPDATE dollar_alerts SET casa=?, kind=?, value=?, enabled=? WHERE id=? AND profile_id=?', [a.casa, a.kind, a.value, a.enabled ? 1 : 0, id, pid]);
  },
  async setEnabled(pid: number, id: number, enabled: boolean): Promise<void> {
    await getDb().run('UPDATE dollar_alerts SET enabled=? WHERE id=? AND profile_id=?', [enabled ? 1 : 0, id, pid]);
  },
  async markFired(id: number, at: string): Promise<void> {
    await getDb().run('UPDATE dollar_alerts SET last_fired_at=? WHERE id=?', [at, id]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM dollar_alerts WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Suscripciones ----------

function mapSub(r: any): Subscription {
  return {
    id: r.id, profileId: r.profile_id, name: r.name, icon: r.icon || 'Receipt', color: r.color || '#8B5CF6', amount: Number(r.amount),
    currency: r.currency === 'USD' ? 'USD' : 'ARS', cycle: r.cycle === 'weekly' || r.cycle === 'yearly' ? r.cycle : 'monthly',
    nextDate: r.next_date, remindDaysBefore: r.remind_days_before ?? null, active: bool(r.active), category: r.category ?? '', createdAt: r.created_at,
  };
}

export type SubscriptionInput = Omit<Subscription, 'id' | 'profileId' | 'createdAt'>;

function validateSub(s: SubscriptionInput) {
  if (!s.name.trim()) throw new Error('Falta el nombre');
  if (!Number.isFinite(s.amount) || s.amount <= 0) throw new Error('El importe debe ser mayor a cero');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s.nextDate)) throw new Error('Falta la fecha del próximo cobro');
}

export const subscriptionsRepo = {
  async list(pid: number, includeInactive = true): Promise<Subscription[]> {
    return (await getDb().all(`SELECT * FROM subscriptions WHERE profile_id = ? ${includeInactive ? '' : 'AND active = 1'} ORDER BY active DESC, next_date, id`, [pid])).map(mapSub);
  },
  async get(pid: number, id: number): Promise<Subscription | null> {
    const r = await getDb().first('SELECT * FROM subscriptions WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapSub(r) : null;
  },
  async create(pid: number, s: SubscriptionInput): Promise<number> {
    validateSub(s);
    const r = await getDb().run(
      'INSERT INTO subscriptions (profile_id, name, icon, color, amount, currency, cycle, next_date, remind_days_before, active, category, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',
      [pid, s.name.trim(), s.icon, s.color, Math.round(s.amount), s.currency, s.cycle, s.nextDate, s.remindDaysBefore, s.active ? 1 : 0, s.category, nowStamp()],
    );
    return r.lastInsertRowId;
  },
  async update(pid: number, id: number, s: SubscriptionInput): Promise<void> {
    validateSub(s);
    await getDb().run(
      'UPDATE subscriptions SET name=?, icon=?, color=?, amount=?, currency=?, cycle=?, next_date=?, remind_days_before=?, active=?, category=? WHERE id=? AND profile_id=?',
      [s.name.trim(), s.icon, s.color, Math.round(s.amount), s.currency, s.cycle, s.nextDate, s.remindDaysBefore, s.active ? 1 : 0, s.category, id, pid],
    );
  },
  async setNextDate(pid: number, id: number, nextDate: string): Promise<void> {
    await getDb().run('UPDATE subscriptions SET next_date=? WHERE id=? AND profile_id=?', [nextDate, id, pid]);
  },
  async setActive(pid: number, id: number, active: boolean): Promise<void> {
    await getDb().run('UPDATE subscriptions SET active=? WHERE id=? AND profile_id=?', [active ? 1 : 0, id, pid]);
  },
  async remove(pid: number, id: number): Promise<void> {
    await getDb().run('DELETE FROM subscriptions WHERE id=? AND profile_id=?', [id, pid]);
  },
};

// ---------- Descubrir ----------

function mapItem(r: any): DiscoverItem {
  return {
    id: r.id, profileId: r.profile_id, topic: r.topic, title: r.title, summary: r.summary ?? '', url: r.url, source: r.source ?? '',
    imageUrl: r.image_url ?? null, publishedAt: r.published_at, saved: bool(r.saved), hidden: bool(r.hidden), opened: bool(r.opened), fetchedAt: r.fetched_at,
  };
}

export type DiscoverItemInput = Pick<DiscoverItem, 'topic' | 'title' | 'summary' | 'url' | 'source' | 'imageUrl' | 'publishedAt'>;

export const discoverRepo = {
  async list(pid: number, limit = 200): Promise<DiscoverItem[]> {
    return (await getDb().all('SELECT * FROM discover_items WHERE profile_id = ? AND hidden = 0 ORDER BY published_at DESC, id DESC LIMIT ?', [pid, limit])).map(mapItem);
  },
  async saved(pid: number): Promise<DiscoverItem[]> {
    return (await getDb().all('SELECT * FROM discover_items WHERE profile_id = ? AND saved = 1 ORDER BY published_at DESC', [pid])).map(mapItem);
  },
  async get(pid: number, id: number): Promise<DiscoverItem | null> {
    const r = await getDb().first('SELECT * FROM discover_items WHERE id = ? AND profile_id = ?', [id, pid]);
    return r ? mapItem(r) : null;
  },
  /** Inserta las publicaciones nuevas (ignora las repetidas por URL). Devuelve cuántas se agregaron. */
  async addMany(pid: number, items: DiscoverItemInput[]): Promise<number> {
    const db = getDb();
    let added = 0;
    const now = nowStamp();
    await db.transaction(async () => {
      for (const it of items) {
        if (!it.url || !it.title) continue;
        const r = await db.run(
          'INSERT OR IGNORE INTO discover_items (profile_id, topic, title, summary, url, source, image_url, published_at, fetched_at) VALUES (?,?,?,?,?,?,?,?,?)',
          [pid, it.topic, it.title.slice(0, 300), (it.summary ?? '').slice(0, 600), it.url, it.source ?? '', it.imageUrl ?? null, it.publishedAt, now],
        );
        added += r.changes;
      }
    });
    return added;
  },
  async setFlag(pid: number, id: number, flag: 'saved' | 'hidden' | 'opened', v: boolean): Promise<void> {
    await getDb().run(`UPDATE discover_items SET ${flag}=? WHERE id=? AND profile_id=?`, [v ? 1 : 0, id, pid]);
  },
  async setImage(pid: number, id: number, url: string | null): Promise<void> {
    await getDb().run('UPDATE discover_items SET image_url=? WHERE id=? AND profile_id=?', [url, id, pid]);
  },
  /** Mantiene como máximo `keep` publicaciones no guardadas por perfil y borra las que ya no corresponden a un tema. */
  async prune(pid: number, keep = 300, topics?: string[]): Promise<void> {
    const db = getDb();
    if (topics) {
      const rows = await db.all<{ id: number; topic: string }>('SELECT id, topic FROM discover_items WHERE profile_id = ? AND saved = 0', [pid]);
      const set = new Set(topics.map((t) => t.toLowerCase()));
      for (const r of rows) if (!set.has(String(r.topic).toLowerCase())) await db.run('DELETE FROM discover_items WHERE id = ?', [r.id]);
    }
    await db.run(
      'DELETE FROM discover_items WHERE profile_id = ? AND saved = 0 AND id NOT IN (SELECT id FROM discover_items WHERE profile_id = ? AND saved = 0 ORDER BY published_at DESC, id DESC LIMIT ?)',
      [pid, pid, keep],
    );
  },
  async lastFetch(pid: number): Promise<string | null> {
    const r = await getDb().first<{ f: string | null }>('SELECT MAX(fetched_at) AS f FROM discover_items WHERE profile_id = ?', [pid]);
    return r?.f ?? null;
  },
};

// ---------- Amigo ----------

function mapMsg(r: any): AssistantMessage {
  return { id: r.id, profileId: r.profile_id, role: r.role === 'user' ? 'user' : 'assistant', text: r.text, payload: parseJSON<Record<string, unknown> | null>(r.payload, null), createdAt: r.created_at };
}

export const assistantRepo = {
  async list(pid: number, limit = 200): Promise<AssistantMessage[]> {
    const rows = await getDb().all('SELECT * FROM assistant_messages WHERE profile_id = ? ORDER BY id DESC LIMIT ?', [pid, limit]);
    return rows.map(mapMsg).reverse();
  },
  async add(pid: number, role: 'user' | 'assistant', text: string, payload: Record<string, unknown> | null = null): Promise<number> {
    const r = await getDb().run('INSERT INTO assistant_messages (profile_id, role, text, payload, created_at) VALUES (?,?,?,?,?)', [pid, role, text, payload ? JSON.stringify(payload) : null, nowStamp()]);
    return r.lastInsertRowId;
  },
  async setPayload(pid: number, id: number, payload: Record<string, unknown> | null): Promise<void> {
    await getDb().run('UPDATE assistant_messages SET payload=? WHERE id=? AND profile_id=?', [payload ? JSON.stringify(payload) : null, id, pid]);
  },
  async clear(pid: number): Promise<void> {
    await getDb().run('DELETE FROM assistant_messages WHERE profile_id = ?', [pid]);
  },
};
