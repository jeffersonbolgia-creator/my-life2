// Descubrir: catálogo de intereses, lector RSS (sin dependencias) y orden del feed según lo que toca el usuario.
// La red está en services/discoverService.ts.

import type { DiscoverItem } from '../types';
import { normalizeText } from '../lib/text';

export interface TopicDef {
  key: string; // nombre visible y clave (ej. "UFC")
  query: string; // consulta de noticias
  icon: string;
  color: string;
}

export interface TopicCategory {
  name: string;
  topics: TopicDef[];
}

/** Catálogo grande de intereses por categoría. El usuario también puede escribir el suyo. */
export const TOPIC_CATALOG: TopicCategory[] = [
  { name: 'Deportes', topics: [
    { key: 'Fútbol', query: 'fútbol argentino', icon: 'Trophy', color: '#22C55E' },
    { key: 'Selección argentina', query: 'selección argentina', icon: 'Flag', color: '#60A5FA' },
    { key: 'UFC', query: 'UFC MMA', icon: 'Swords', color: '#F43F5E' },
    { key: 'Boxeo', query: 'boxeo', icon: 'Swords', color: '#EF4444' },
    { key: 'Básquet', query: 'NBA básquet', icon: 'Dribbble', color: '#F97316' },
    { key: 'Tenis', query: 'tenis ATP', icon: 'CircleDot', color: '#84CC16' },
    { key: 'Fórmula 1', query: 'Fórmula 1', icon: 'Flag', color: '#EF4444' },
    { key: 'Rugby', query: 'rugby Los Pumas', icon: 'Trophy', color: '#0EA5E9' },
    { key: 'Gimnasio', query: 'entrenamiento gimnasio', icon: 'Dumbbell', color: '#10B981' },
  ] },
  { name: 'Videojuegos y tecnología', topics: [
    { key: 'Videojuegos', query: 'videojuegos', icon: 'Gamepad2', color: '#3B82F6' },
    { key: 'PlayStation', query: 'PlayStation', icon: 'Gamepad2', color: '#2563EB' },
    { key: 'Nintendo', query: 'Nintendo Switch', icon: 'Gamepad2', color: '#EF4444' },
    { key: 'PC gamer', query: 'PC gaming hardware', icon: 'Monitor', color: '#8B5CF6' },
    { key: 'Tecnología', query: 'tecnología', icon: 'Cpu', color: '#A78BFA' },
    { key: 'Celulares', query: 'celulares smartphones', icon: 'Smartphone', color: '#06B6D4' },
    { key: 'Inteligencia artificial', query: 'inteligencia artificial', icon: 'Brain', color: '#D946EF' },
    { key: 'Programación', query: 'programación desarrollo software', icon: 'Code', color: '#22D3EE' },
    { key: 'Ciberseguridad', query: 'ciberseguridad', icon: 'ShieldCheck', color: '#F59E0B' },
  ] },
  { name: 'Entretenimiento', topics: [
    { key: 'Cine', query: 'cine estrenos películas', icon: 'Clapperboard', color: '#F43F5E' },
    { key: 'Series', query: 'series streaming', icon: 'Tv', color: '#E11D48' },
    { key: 'Anime', query: 'anime manga', icon: 'Sparkles', color: '#F472B6' },
    { key: 'Música', query: 'música', icon: 'Music', color: '#22C55E' },
    { key: 'Trap y rap', query: 'trap argentino rap', icon: 'Mic', color: '#A855F7' },
    { key: 'Rock', query: 'rock nacional', icon: 'Guitar', color: '#F97316' },
    { key: 'K-pop', query: 'k-pop', icon: 'Music', color: '#EC4899' },
    { key: 'Humor', query: 'humor virales', icon: 'Laugh', color: '#FBBF24' },
    { key: 'Streamers', query: 'streamers Twitch YouTube', icon: 'Video', color: '#9146FF' },
  ] },
  { name: 'Economía y trabajo', topics: [
    { key: 'Dólar y economía', query: 'dólar economía argentina', icon: 'CircleDollarSign', color: '#34D399' },
    { key: 'Inversiones', query: 'inversiones ahorro', icon: 'TrendingUp', color: '#10B981' },
    { key: 'Cripto', query: 'bitcoin criptomonedas', icon: 'Bitcoin', color: '#F59E0B' },
    { key: 'Emprender', query: 'emprendedores negocios', icon: 'Rocket', color: '#F97316' },
    { key: 'Trabajo', query: 'empleo trabajo', icon: 'Briefcase', color: '#64748B' },
  ] },
  { name: 'Estilo de vida', topics: [
    { key: 'Cocina', query: 'recetas cocina', icon: 'ChefHat', color: '#F97316' },
    { key: 'Salud', query: 'salud bienestar', icon: 'HeartPulse', color: '#EF4444' },
    { key: 'Viajes', query: 'viajes turismo', icon: 'Plane', color: '#0EA5E9' },
    { key: 'Moda', query: 'moda tendencias', icon: 'Shirt', color: '#EC4899' },
    { key: 'Autos', query: 'autos', icon: 'Car', color: '#64748B' },
    { key: 'Motos', query: 'motos', icon: 'Bike', color: '#F59E0B' },
    { key: 'Mascotas', query: 'mascotas perros gatos', icon: 'PawPrint', color: '#A16207' },
    { key: 'Fotografía', query: 'fotografía', icon: 'Camera', color: '#6366F1' },
    { key: 'Naturaleza', query: 'naturaleza medio ambiente', icon: 'Leaf', color: '#22C55E' },
  ] },
  { name: 'Cultura y ciencia', topics: [
    { key: 'Ciencia', query: 'ciencia', icon: 'Atom', color: '#8B5CF6' },
    { key: 'Espacio', query: 'espacio NASA astronomía', icon: 'Rocket', color: '#6366F1' },
    { key: 'Historia', query: 'historia', icon: 'Landmark', color: '#A16207' },
    { key: 'Libros', query: 'libros literatura', icon: 'BookOpen', color: '#F59E0B' },
    { key: 'Arte', query: 'arte', icon: 'Palette', color: '#EC4899' },
    { key: 'Noticias', query: 'Argentina', icon: 'Newspaper', color: '#94A3B8' },
  ] },
];

export const ALL_TOPICS: TopicDef[] = TOPIC_CATALOG.flatMap((c) => c.topics);

export function topicDef(key: string): TopicDef {
  const k = normalizeText(key);
  return ALL_TOPICS.find((t) => normalizeText(t.key) === k) ?? { key, query: key, icon: 'Hash', color: '#A78BFA' };
}

/** Intereses de la bienvenida que se corresponden con temas del catálogo. */
export function topicsFromInterests(interests: string[]): string[] {
  const map: Record<string, string> = {
    tecnologia: 'Tecnología', videojuegos: 'Videojuegos', musica: 'Música', deportes: 'Fútbol', lectura: 'Libros', 'cine y series': 'Cine',
    cocina: 'Cocina', viajes: 'Viajes', moda: 'Moda', fotografia: 'Fotografía', ciencia: 'Ciencia', emprender: 'Emprender', naturaleza: 'Naturaleza',
    autos: 'Autos', anime: 'Anime', futbol: 'Fútbol', ufc: 'UFC', gimnasio: 'Gimnasio', basquet: 'Básquet', programacion: 'Programación',
  };
  const out: string[] = [];
  for (const i of interests) {
    const k = normalizeText(i);
    const t = map[k] ?? (ALL_TOPICS.find((x) => normalizeText(x.key) === k)?.key ?? null);
    if (t && !out.includes(t)) out.push(t);
  }
  return out;
}

// ---------- RSS ----------

export interface RssItem {
  title: string;
  link: string;
  summary: string;
  source: string;
  publishedAt: string; // ISO
  imageUrl: string | null;
}

const ENTITIES: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', '#39': "'", '#x27': "'" };

export function decodeEntities(s: string): string {
  return s.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (m, code: string) => {
    if (ENTITIES[code] != null) return ENTITIES[code];
    if (code.startsWith('#x')) return String.fromCodePoint(parseInt(code.slice(2), 16));
    if (code.startsWith('#')) return String.fromCodePoint(parseInt(code.slice(1), 10));
    return m;
  });
}

export function stripHtml(s: string): string {
  return decodeEntities(s.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
}

function tag(xml: string, name: string): string | null {
  const m = xml.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i'));
  if (!m) return null;
  let v = m[1].trim();
  const cdata = v.match(/^<!\[CDATA\[([\s\S]*?)\]\]>$/);
  if (cdata) v = cdata[1];
  return v.trim();
}

function attr(xml: string, tagName: string, attrName: string): string | null {
  const m = xml.match(new RegExp(`<${tagName}[^>]*\\s${attrName}=["']([^"']+)["']`, 'i'));
  return m ? m[1] : null;
}

/** Interpreta un feed RSS 2.0 o Atom. Devuelve los ítems en el orden del feed. */
export function parseRss(xml: string): RssItem[] {
  const items: RssItem[] = [];
  const chunks = xml.match(/<item(?:\s[^>]*)?>[\s\S]*?<\/item>/gi) ?? xml.match(/<entry(?:\s[^>]*)?>[\s\S]*?<\/entry>/gi) ?? [];
  for (const c of chunks) {
    const title = stripHtml(tag(c, 'title') ?? '');
    let link = tag(c, 'link') ?? attr(c, 'link', 'href') ?? '';
    link = decodeEntities(link.trim());
    if (!title || !/^https?:\/\//i.test(link)) continue;
    const rawDesc = tag(c, 'description') ?? tag(c, 'summary') ?? tag(c, 'content') ?? '';
    const summary = stripHtml(rawDesc).slice(0, 400);
    const source = stripHtml(tag(c, 'source') ?? tag(c, 'dc:creator') ?? tag(c, 'author') ?? '');
    const dateRaw = tag(c, 'pubDate') ?? tag(c, 'published') ?? tag(c, 'updated') ?? tag(c, 'dc:date') ?? '';
    const d = new Date(dateRaw);
    const publishedAt = Number.isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
    const img = attr(c, 'media:content', 'url') ?? attr(c, 'media:thumbnail', 'url') ?? attr(c, 'enclosure', 'url') ?? (rawDesc.match(/<img[^>]+src=["']([^"']+)["']/i)?.[1] ?? null);
    items.push({ title, link, summary, source, publishedAt, imageUrl: img && /^https?:\/\//i.test(img) ? decodeEntities(img) : null });
  }
  return items;
}

/** URL del feed de noticias para un tema (Google News en español de Argentina). */
export function newsFeedUrl(query: string): string {
  return `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=es-419&gl=AR&ceid=AR:es-419`;
}

/** Google News mete el nombre del medio al final del título: "Título - Medio". Lo separamos. */
export function splitSourceFromTitle(title: string, source: string): { title: string; source: string } {
  const m = title.match(/^(.*)\s[-–]\s([^-–]{2,40})$/);
  if (m && (!source || normalizeText(m[2]) === normalizeText(source))) return { title: m[1].trim(), source: source || m[2].trim() };
  return { title, source };
}

// ---------- Orden del feed (aprendizaje local) ----------

/** Pesos por tema: cada toque suma, cada "menos de esto" resta. */
export function adjustWeight(weights: Record<string, number>, topic: string, delta: number): Record<string, number> {
  const next = { ...weights };
  next[topic] = Math.max(-5, Math.min(10, (next[topic] ?? 0) + delta));
  return next;
}

/**
 * Orden del feed: más nuevo primero, pero los temas que el usuario toca suben
 * y se intercalan temas para que no sea todo lo mismo.
 */
export function rankItems(items: DiscoverItem[], weights: Record<string, number>, now: Date = new Date()): DiscoverItem[] {
  const scored = items.map((it) => {
    const ageH = Math.max(0, (now.getTime() - new Date(it.publishedAt).getTime()) / 3600_000);
    const recency = Math.max(0, 48 - ageH) / 48; // 0..1, cae en 2 días
    const w = weights[it.topic] ?? 0;
    return { it, score: recency * 10 + w * 1.5 + (it.imageUrl ? 0.5 : 0) };
  });
  scored.sort((a, b) => b.score - a.score || b.it.publishedAt.localeCompare(a.it.publishedAt));
  // Intercalar: no más de 2 seguidas del mismo tema
  const out: DiscoverItem[] = [];
  const pending = [...scored.map((s) => s.it)];
  while (pending.length) {
    const last2 = out.slice(-2).map((x) => x.topic);
    const idx = pending.findIndex((x) => !(last2.length === 2 && last2[0] === x.topic && last2[1] === x.topic));
    out.push(pending.splice(idx === -1 ? 0 : idx, 1)[0]);
  }
  return out;
}
