import type { Habit } from '../types';
import { addDays, startOfWeek, weekday, diffDays } from '../lib/dates';

/** ¿El hábito se debe cumplir ese día? (para hábitos semanales, cualquier día cuenta) */
export function isScheduledOn(habit: Habit, date: string): boolean {
  if (date < habit.createdAt.slice(0, 10)) return false;
  if (habit.frequency === 'weekly') return true;
  if (!habit.weekdays.length) return true;
  return habit.weekdays.includes(weekday(date));
}

function countInWeek(logs: Set<string>, weekStart: string): number {
  let n = 0;
  for (let i = 0; i < 7; i++) if (logs.has(addDays(weekStart, i))) n++;
  return n;
}

/**
 * Racha actual.
 * - Diarios: días programados consecutivos cumplidos. Si hoy todavía no se cumplió,
 *   la racha no se corta (se cuenta desde ayer).
 * - Semanales: semanas consecutivas en las que se alcanzó el objetivo. La semana actual
 *   suma si ya se alcanzó, y no corta la racha si todavía no.
 */
export function currentStreak(habit: Habit, logs: Set<string>, today: string): number {
  const created = habit.createdAt.slice(0, 10);
  if (habit.frequency === 'weekly') {
    const target = Math.max(1, habit.targetPerWeek);
    let ws = startOfWeek(today);
    let streak = 0;
    if (countInWeek(logs, ws) >= target) streak++;
    ws = addDays(ws, -7);
    let guard = 0;
    while (guard++ < 520 && addDays(ws, 6) >= created) {
      if (countInWeek(logs, ws) >= target) streak++;
      else break;
      ws = addDays(ws, -7);
    }
    return streak;
  }
  let streak = 0;
  let d = today;
  if (isScheduledOn(habit, d) && !logs.has(d)) d = addDays(d, -1);
  let guard = 0;
  while (guard++ < 3700 && d >= created) {
    if (isScheduledOn(habit, d)) {
      if (logs.has(d)) streak++;
      else break;
    }
    d = addDays(d, -1);
  }
  return streak;
}

/** Mejor racha histórica (solo hábitos diarios; para semanales se calcula por semanas). */
export function bestStreak(habit: Habit, logs: Set<string>, today: string): number {
  const created = habit.createdAt.slice(0, 10);
  let best = 0;
  let run = 0;
  if (habit.frequency === 'weekly') {
    const target = Math.max(1, habit.targetPerWeek);
    let ws = startOfWeek(created);
    const last = startOfWeek(today);
    let guard = 0;
    while (ws <= last && guard++ < 520) {
      if (countInWeek(logs, ws) >= target) {
        run++;
        best = Math.max(best, run);
      } else if (ws !== last) run = 0;
      ws = addDays(ws, 7);
    }
    return best;
  }
  let d = created;
  let guard = 0;
  while (d <= today && guard++ < 3700) {
    if (isScheduledOn(habit, d)) {
      if (logs.has(d)) {
        run++;
        best = Math.max(best, run);
      } else if (d !== today) run = 0;
    }
    d = addDays(d, 1);
  }
  return best;
}

/** Porcentaje de cumplimiento entre dos fechas (inclusive). */
export function completionRate(habit: Habit, logs: Set<string>, from: string, to: string): number {
  const created = habit.createdAt.slice(0, 10);
  const start = from < created ? created : from;
  if (start > to) return 0;
  if (habit.frequency === 'weekly') {
    const target = Math.max(1, habit.targetPerWeek);
    const weeks = Math.max(1, Math.ceil((diffDays(to, start) + 1) / 7));
    let done = 0;
    let d = start;
    while (d <= to) {
      if (logs.has(d)) done++;
      d = addDays(d, 1);
    }
    return Math.min(100, Math.round((done / (weeks * target)) * 100));
  }
  let scheduled = 0;
  let done = 0;
  let d = start;
  while (d <= to) {
    if (isScheduledOn(habit, d)) {
      scheduled++;
      if (logs.has(d)) done++;
    }
    d = addDays(d, 1);
  }
  return scheduled ? Math.round((done / scheduled) * 100) : 0;
}

export function weekProgress(habit: Habit, logs: Set<string>, today: string): { done: number; target: number } {
  const ws = startOfWeek(today);
  if (habit.frequency === 'weekly') return { done: countInWeek(logs, ws), target: Math.max(1, habit.targetPerWeek) };
  let target = 0;
  let done = 0;
  for (let i = 0; i < 7; i++) {
    const d = addDays(ws, i);
    if (habit.weekdays.length === 0 || habit.weekdays.includes(weekday(d))) {
      target++;
      if (logs.has(d)) done++;
    }
  }
  return { done, target };
}
