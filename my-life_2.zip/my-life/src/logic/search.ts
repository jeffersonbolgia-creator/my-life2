// Búsqueda general dentro de los datos de UN perfil.
// `searchAll` carga los datos del perfil activo y `searchItems` filtra (sin efectos secundarios, testeable).

import type { CalendarEvent, Countdown, Goal, Habit, Note, Reminder, Routine, Task, Transaction } from '../types';
import { countdownsRepo, eventsRepo, financeRepo, goalsRepo, habitsRepo, notesRepo, remindersRepo, routinesRepo, tasksRepo } from '../db/repos';
import { matchesSearch, normalizeText } from '../lib/text';
import { formatMoney } from '../lib/money';
import { formatRelativeDay } from '../lib/dates';

export type SearchKind = 'task' | 'event' | 'note' | 'tx' | 'habit' | 'goal' | 'reminder' | 'countdown' | 'routine';

export interface SearchResult {
  kind: SearchKind;
  id: number;
  title: string;
  subtitle: string;
  /** Pantalla y parámetros para abrir el resultado. */
  route: string;
  params?: Record<string, unknown>;
  /** Puntaje: mayor = más relevante. */
  score: number;
}

export const SEARCH_KIND_LABELS: Record<SearchKind, { label: string; icon: string; color: string }> = {
  task: { label: 'Tareas', icon: 'CircleCheck', color: '#8B5CF6' },
  event: { label: 'Eventos', icon: 'CalendarDays', color: '#3B82F6' },
  note: { label: 'Notas', icon: 'NotebookPen', color: '#F59E0B' },
  tx: { label: 'Movimientos', icon: 'Wallet', color: '#10B981' },
  habit: { label: 'Hábitos', icon: 'Repeat', color: '#06B6D4' },
  goal: { label: 'Objetivos', icon: 'Target', color: '#D946EF' },
  reminder: { label: 'Recordatorios', icon: 'BellRing', color: '#F97316' },
  countdown: { label: 'Cuentas regresivas', icon: 'Hourglass', color: '#A78BFA' },
  routine: { label: 'Rutinas', icon: 'Sunrise', color: '#FBBF24' },
};

export const SEARCH_KIND_ORDER: SearchKind[] = ['task', 'event', 'reminder', 'note', 'tx', 'habit', 'goal', 'countdown', 'routine'];

export interface SearchData {
  tasks: Task[];
  events: CalendarEvent[];
  notes: Note[];
  txs: Transaction[];
  habits: Habit[];
  goals: Goal[];
  reminders: Reminder[];
  countdowns: Countdown[];
  routines: Routine[];
}

function score(query: string, title: string, extra = ''): number {
  const q = normalizeText(query);
  const t = normalizeText(title);
  if (!q) return 0;
  if (t === q) return 100;
  if (t.startsWith(q)) return 80;
  if (t.includes(q)) return 60;
  if (matchesSearch(title, query)) return 40;
  if (matchesSearch(extra, query)) return 20;
  return 0;
}

export function searchItems(data: SearchData, query: string, limitPerKind = 8): SearchResult[] {
  const q = query.trim();
  if (q.length < 2) return [];
  const out: SearchResult[] = [];
  const push = (r: Omit<SearchResult, 'score'>, s: number) => {
    if (s > 0) out.push({ ...r, score: s });
  };

  for (const t of data.tasks) {
    push({ kind: 'task', id: t.id, title: t.title, subtitle: `${t.completedAt ? 'Completada' : t.dueDate ? formatRelativeDay(t.dueDate) : 'Sin fecha'}${t.category ? ' · ' + t.category : ''}`, route: 'TaskForm', params: { id: t.id } },
      score(q, t.title, `${t.description} ${t.category}`));
  }
  for (const e of data.events) {
    push({ kind: 'event', id: e.id, title: e.title, subtitle: `${formatRelativeDay(e.date)}${e.location ? ' · ' + e.location : ''}`, route: 'EventForm', params: { id: e.id } },
      score(q, e.title, `${e.location} ${e.notes}`));
  }
  for (const n of data.notes) {
    const body = n.isList ? n.items.map((i) => i.text).join(' ') : n.body;
    push({ kind: 'note', id: n.id, title: n.title || body.slice(0, 40) || 'Nota', subtitle: n.category || (n.isList ? 'Lista' : 'Nota'), route: 'NoteEditor', params: { id: n.id } },
      score(q, n.title, body));
  }
  for (const x of data.txs) {
    push({ kind: 'tx', id: x.id, title: x.name, subtitle: `${x.kind === 'income' ? '+' : '-'}${formatMoney(x.amount)} · ${formatRelativeDay(x.date)} · ${x.category}`, route: 'TxForm', params: { id: x.id } },
      score(q, x.name, `${x.category} ${x.description}`));
  }
  for (const h of data.habits) {
    push({ kind: 'habit', id: h.id, title: h.title, subtitle: h.frequency === 'weekly' ? `${h.targetPerWeek} veces por semana` : 'Diario', route: 'HabitForm', params: { id: h.id } }, score(q, h.title));
  }
  for (const g of data.goals) {
    push({ kind: 'goal', id: g.id, title: g.title, subtitle: `${g.progress}%${g.targetDate ? ' · ' + formatRelativeDay(g.targetDate) : ''}`, route: 'GoalForm', params: { id: g.id } }, score(q, g.title, g.description));
  }
  for (const r of data.reminders) {
    push({ kind: 'reminder', id: r.id, title: r.title, subtitle: `${formatRelativeDay(r.date)} · ${r.time}${r.amount ? ' · ' + formatMoney(r.amount) : ''}`, route: 'ReminderForm', params: { id: r.id } }, score(q, r.title, r.notes));
  }
  for (const c of data.countdowns) {
    push({ kind: 'countdown', id: c.id, title: c.title, subtitle: formatRelativeDay(c.date), route: 'CountdownForm', params: { id: c.id } }, score(q, c.title));
  }
  for (const r of data.routines) {
    push({ kind: 'routine', id: r.id, title: r.title, subtitle: `${r.steps.length} pasos${r.startTime ? ' · ' + r.startTime : ''}`, route: 'RoutineForm', params: { id: r.id } }, score(q, r.title, r.steps.map((s) => s.title).join(' ')));
  }

  out.sort((a, b) => b.score - a.score || a.title.localeCompare(b.title));
  const perKind = new Map<SearchKind, number>();
  return out.filter((r) => {
    const n = (perKind.get(r.kind) ?? 0) + 1;
    perKind.set(r.kind, n);
    return n <= limitPerKind;
  });
}

export function groupResults(results: SearchResult[]): { kind: SearchKind; items: SearchResult[] }[] {
  return SEARCH_KIND_ORDER.map((kind) => ({ kind, items: results.filter((r) => r.kind === kind) })).filter((g) => g.items.length);
}

/** Carga todos los datos del perfil (sólo de ese perfil) para buscar. */
export async function loadSearchData(pid: number): Promise<SearchData> {
  const [tasks, events, notes, txs, habits, goals, reminders, countdowns, routines] = await Promise.all([
    tasksRepo.list(pid), eventsRepo.list(pid), notesRepo.list(pid), financeRepo.list(pid), habitsRepo.list(pid, true),
    goalsRepo.list(pid), remindersRepo.list(pid), countdownsRepo.list(pid), routinesRepo.list(pid, true),
  ]);
  return { tasks, events, notes, txs, habits, goals, reminders, countdowns, routines };
}
