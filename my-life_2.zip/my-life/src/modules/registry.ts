// Registro de módulos. Para agregar un módulo nuevo alcanza con sumarlo acá,
// a `ModuleKey` en types.ts y a `defaultModules()` en defaults.ts.
// Las tarjetas del inicio y las pantallas consultan este registro.

import type { DashboardCardKey, ModuleKey } from '../types';

export interface ModuleDef {
  key: ModuleKey;
  label: string;
  description: string;
  icon: string;
  color: string;
  /** Pantalla que abre el módulo desde "Más". */
  route: string;
  /** Tarjetas del inicio que aporta. */
  cards: DashboardCardKey[];
  /** false = todavía no está disponible (llega en una próxima versión). */
  available: boolean;
}

export const MODULES: ModuleDef[] = [
  {
    key: 'countdown',
    label: 'Cuenta regresiva',
    description: 'Cuántos días faltan para lo que esperás',
    icon: 'Hourglass',
    color: '#A78BFA',
    route: 'Countdowns',
    cards: ['countdown'],
    available: true,
  },
  {
    key: 'routines',
    label: 'Rutinas',
    description: 'Tu mañana (o tu noche) paso a paso',
    icon: 'Sunrise',
    color: '#FBBF24',
    route: 'Routines',
    cards: ['routine'],
    available: true,
  },
  {
    key: 'dollar',
    label: 'Dólar hoy',
    description: 'Cotizaciones, gráfico y alertas',
    icon: 'CircleDollarSign',
    color: '#34D399',
    route: 'Dollar',
    cards: ['dollar'],
    available: true,
  },
  {
    key: 'subscriptions',
    label: 'Suscripciones',
    description: 'Cuánto falta para cada cobro',
    icon: 'Repeat2',
    color: '#FB923C',
    route: 'Subscriptions',
    cards: ['subscriptions'],
    available: true,
  },
  {
    key: 'discover',
    label: 'Descubrir',
    description: 'Noticias de tus intereses, cada día',
    icon: 'Compass',
    color: '#F472B6',
    route: 'Discover',
    cards: ['discover'],
    available: true,
  },
  {
    key: 'assistant',
    label: 'Tu amigo',
    description: 'Un chat que conoce tus datos, sin internet',
    icon: 'Sparkles',
    color: '#C4B5FD',
    route: 'Assistant',
    cards: [],
    available: true,
  },
];

export function moduleDef(key: ModuleKey): ModuleDef {
  return MODULES.find((m) => m.key === key)!;
}

export function isModuleOn(modules: Record<ModuleKey, boolean>, key: ModuleKey): boolean {
  const def = moduleDef(key);
  return !!def && def.available && !!modules[key];
}
