import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useProfile } from '../../state/AppContext';
import { ChipGroup, DateField, Field, FormActions, Screen, T, TimeField } from '../../ui/kit';
import { tasksRepo } from '../../db/repos';
import { TASK_CATEGORIES } from '../../db/defaults';
import { PRIORITY_COLORS, PRIORITY_LABELS, REMIND_OPTIONS } from './shared';
import type { Priority } from '../../types';
import { success, toast } from '../../ui/haptics';
import { todayISO } from '../../lib/dates';

export default function TaskFormScreen({ navigation, route }: any) {
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const pre = route.params?.prefill ?? null;
  const [title, setTitle] = useState<string>(pre?.title ?? '');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState<string | null>(pre?.date ?? route.params?.date ?? null);
  const [dueTime, setDueTime] = useState<string | null>(pre?.time ?? null);
  const [priority, setPriority] = useState<Priority>(1);
  const [category, setCategory] = useState('');
  const [customCat, setCustomCat] = useState('');
  const [extraCat, setExtraCat] = useState('');
  const [remind, setRemind] = useState(-1);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    if (!id) return;
    tasksRepo.get(profile.id, id).then((x) => {
      if (!x) return;
      setTitle(x.title);
      setDescription(x.description);
      setDueDate(x.dueDate);
      setDueTime(x.dueTime);
      setPriority(x.priority);
      setCategory(x.category);
      if (x.category && !TASK_CATEGORIES.includes(x.category)) setExtraCat(x.category);
      setRemind(x.remindMinutes ?? -1);
      setCompleted(!!x.completedAt);
    });
  }, [id, profile.id]);

  const save = async () => {
    if (!title.trim()) {
      setError('Escribí un título');
      return;
    }
    setSaving(true);
    const data = {
      title: title.trim(),
      description: description.trim(),
      dueDate: dueDate ?? (dueTime ? todayISO() : null),
      dueTime: dueTime,
      priority,
      category,
      remindMinutes: remind < 0 ? null : remind,
    };
    try {
      if (id) await tasksRepo.update(profile.id, id, data);
      else await tasksRepo.create(profile.id, data);
      success();
      toast(id ? 'Tarea actualizada' : 'Tarea creada');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar tarea', '¿Seguro que querés eliminarla?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await tasksRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  const allCats = [...new Set([...TASK_CATEGORIES, ...(extraCat ? [extraCat] : [])])];

  return (
    <Screen title={id ? 'Editar tarea' : 'Nueva tarea'} back>
      <Field label="Título" value={title} onChangeText={(v) => { setTitle(v); setError(null); }} placeholder="¿Qué tenés que hacer?" autoFocus={!id} error={error} maxLength={120} />
      <Field label="Descripción (opcional)" value={description} onChangeText={setDescription} placeholder="Detalles, pasos, links..." multiline />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <DateField label="Fecha límite" value={dueDate} onChange={setDueDate} />
      </View>
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <TimeField label="Hora" value={dueTime} onChange={setDueTime} />
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Aviso</T>
        <ChipGroup options={REMIND_OPTIONS} value={remind} onChange={setRemind} />
        {remind >= 0 && !dueDate && !dueTime ? <T variant="small" muted>Para recibir el aviso, elegí una fecha.</T> : null}
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Prioridad</T>
        <ChipGroup
          options={([0, 1, 2] as Priority[]).map((p) => ({ value: p, label: PRIORITY_LABELS[p], color: PRIORITY_COLORS[p], icon: 'Flag' }))}
          value={priority}
          onChange={setPriority}
        />
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Categoría</T>
        <ChipGroup options={[{ value: '', label: 'Ninguna' }, ...allCats.map((c) => ({ value: c, label: c }))]} value={category} onChange={(v: string) => { setCategory(v); setCustomCat(''); }} />
        <Field value={customCat} onChangeText={(v) => { setCustomCat(v); setCategory(v.trim()); }} placeholder="O escribí una categoría nueva" maxLength={30} />
      </View>
      {id && completed ? <T variant="small" muted>Esta tarea está completada.</T> : null}
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
