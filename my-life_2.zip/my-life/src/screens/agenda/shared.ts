import type { EventType, Priority } from '../../types';

export const PRIORITY_COLORS: Record<Priority, string> = { 0: '#64748B', 1: '#8B5CF6', 2: '#F43F5E' };
export const PRIORITY_LABELS: Record<Priority, string> = { 0: 'Baja', 1: 'Media', 2: 'Alta' };

export const EVENT_TYPES: { value: EventType; label: string; icon: string; color: string }[] = [
  { value: 'event', label: 'Evento', icon: 'CalendarDays', color: '#3B82F6' },
  { value: 'appointment', label: 'Cita', icon: 'CalendarClock', color: '#8B5CF6' },
  { value: 'birthday', label: 'Cumpleaños', icon: 'Cake', color: '#F43F5E' },
  { value: 'important', label: 'Importante', icon: 'Star', color: '#F59E0B' },
  { value: 'schedule', label: 'Horario', icon: 'Clock', color: '#10B981' },
];

export function eventMeta(type: EventType) {
  return EVENT_TYPES.find((e) => e.value === type) ?? EVENT_TYPES[0];
}

export const REMIND_OPTIONS: { value: number; label: string }[] = [
  { value: -1, label: 'Sin aviso' },
  { value: 0, label: 'A la hora' },
  { value: 10, label: '10 min antes' },
  { value: 30, label: '30 min antes' },
  { value: 60, label: '1 h antes' },
  { value: 1440, label: '1 día antes' },
];
