import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useTheme } from '../../state/AppContext';
import { Card, ProgressBar, ProgressRing, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { daysLabel, daysLeft, progress, remaining } from '../../logic/countdown';
import { formatLongDate, capitalize } from '../../lib/dates';
import type { Countdown } from '../../types';

/** Reloj que se actualiza cada minuto (o cada segundo si falta menos de un día). */
export function useNow(fast = false): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), fast ? 1000 : 30_000);
    return () => clearInterval(id);
  }, [fast]);
  return now;
}

const pad = (n: number) => (n < 10 ? '0' + n : String(n));

function Unit({ value, label }: { value: string; label: string }) {
  const t = useTheme();
  return (
    <View style={{ alignItems: 'center', minWidth: 62, paddingVertical: 10, paddingHorizontal: 12, borderRadius: t.radius.md, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border }}>
      <T variant="title">{value}</T>
      <T variant="small" muted>{label}</T>
    </View>
  );
}

/** Tarjeta grande y vistosa con anillo de progreso. */
export function CountdownHero({ c, onPress }: { c: Countdown; onPress?: () => void }) {
  const t = useTheme();
  const now = useNow(daysLeft(c, new Date()) <= 1);
  const r = remaining(c, now);
  const days = daysLeft(c, now);
  const pct = progress(c, now);
  const big = r.today ? 'Hoy' : r.past ? String(-days) : String(days);
  const unit = r.today ? '' : days === 1 || days === -1 ? 'día' : 'días';
  return (
    <Card onPress={onPress} gradient accentBorder padding={20}>
      <View style={{ alignItems: 'center', gap: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Icon name={c.icon} size={16} color={c.color} />
          <T variant="label" color={c.color}>{c.title}</T>
        </View>
        <ProgressRing value={r.past ? 100 : pct} size={190} stroke={12} color={c.color}>
          <View style={{ alignItems: 'center' }}>
            <T variant="display" style={{ fontSize: r.today ? 40 : 60, lineHeight: r.today ? 48 : 66, letterSpacing: -2 }}>{big}</T>
            {unit ? <T secondary>{r.past ? `${unit} atrás` : unit}</T> : <T secondary>¡Llegó el día!</T>}
          </View>
        </ProgressRing>
        {!r.past && !r.today ? (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Unit value={String(r.days)} label="días" />
            <Unit value={pad(r.hours)} label="horas" />
            <Unit value={pad(r.minutes)} label="min" />
            {days <= 1 ? <Unit value={pad(r.seconds)} label="seg" /> : null}
          </View>
        ) : null}
        <T variant="caption" secondary>{capitalize(formatLongDate(c.date))}{c.time ? ` · ${c.time}` : ''}</T>
      </View>
    </Card>
  );
}

/** Fila compacta para la lista y para el inicio. */
export function CountdownRow({ c, onPress }: { c: Countdown; onPress?: () => void }) {
  const t = useTheme();
  const now = new Date();
  const days = daysLeft(c, now);
  const pct = progress(c, now);
  const label = days === 0 ? 'Hoy' : days === 1 ? 'Mañana' : days > 1 ? `${days} días` : `hace ${-days} d`;
  const color = days < 0 ? t.c.textMuted : c.color;
  return (
    <Card onPress={onPress} padding={14}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: c.color + (t.dark ? '24' : '1A'), alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={c.icon} size={20} color={c.color} />
        </View>
        <View style={{ flex: 1, gap: 6 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', gap: 10 }}>
            <T variant="bodyStrong" numberOfLines={1} style={{ flex: 1 }}>{c.title}</T>
            <T variant="heading" color={color}>{label}</T>
          </View>
          <ProgressBar value={days < 0 ? 100 : pct} color={color} height={6} />
          <T variant="small" muted>{daysLabel(c, now)} · {capitalize(formatLongDate(c.date))}</T>
        </View>
      </View>
    </Card>
  );
}
