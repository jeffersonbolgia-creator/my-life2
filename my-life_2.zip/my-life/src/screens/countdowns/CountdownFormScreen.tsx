import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, ChipGroup, DateField, Field, FormActions, Screen, T, TimeField, ToggleRow } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { countdownsRepo, eventsRepo } from '../../db/repos';
import { CATEGORY_COLORS } from '../../theme/theme';
import { COUNTDOWN_ICONS } from '../../db/defaults';
import { todayISO } from '../../lib/dates';
import { success, toast } from '../../ui/haptics';
import type { CalendarEvent } from '../../types';

const REMIND_OPTIONS = [
  { value: -1, label: 'Sin aviso' },
  { value: 0, label: 'El mismo día' },
  { value: 1, label: '1 día antes' },
  { value: 3, label: '3 días antes' },
  { value: 7, label: '1 semana antes' },
];

export default function CountdownFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const fromEvent: number | undefined = route.params?.eventId;
  const [title, setTitle] = useState('');
  const [date, setDate] = useState<string | null>(null);
  const [time, setTime] = useState<string | null>(null);
  const [icon, setIcon] = useState('Star');
  const [color, setColor] = useState('#A78BFA');
  const [remind, setRemind] = useState(-1);
  const [pinned, setPinned] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [events, setEvents] = useState<CalendarEvent[]>([]);

  useEffect(() => {
    if (id) {
      countdownsRepo.get(profile.id, id).then((c) => {
        if (!c) return;
        setTitle(c.title); setDate(c.date); setTime(c.time); setIcon(c.icon); setColor(c.color);
        setRemind(c.remindDaysBefore ?? -1); setPinned(c.pinned);
      });
    } else {
      // Para convertir un evento del calendario en cuenta regresiva
      const today = todayISO();
      eventsRepo.list(profile.id).then((all) => {
        const next = all.filter((e) => e.recurrence === 'none' && e.date >= today && e.type !== 'schedule').slice(0, 6);
        setEvents(next);
        if (fromEvent) {
          const e = all.find((x) => x.id === fromEvent);
          if (e) applyEvent(e);
        }
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, profile.id]);

  const applyEvent = (e: CalendarEvent) => {
    setTitle(e.type === 'birthday' ? `Cumple de ${e.title}` : e.title);
    setDate(e.date);
    setTime(e.allDay ? null : e.startTime);
    if (e.type === 'birthday') { setIcon('Cake'); setColor('#F43F5E'); }
    setError(null);
  };

  const save = async () => {
    if (!title.trim()) return setError('Escribí qué estás esperando');
    if (!date) return Alert.alert('Fecha', 'Elegí la fecha.');
    setSaving(true);
    const data = { title: title.trim(), date, time, icon, color, remindDaysBefore: remind < 0 ? null : remind, pinned };
    try {
      if (id) await countdownsRepo.update(profile.id, id, data);
      else await countdownsRepo.create(profile.id, data);
      success();
      toast('Cuenta regresiva guardada');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar', '¿Borrar esta cuenta regresiva?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await countdownsRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  return (
    <Screen title={id ? 'Editar cuenta regresiva' : 'Nueva cuenta regresiva'} back>
      <Field label="¿Qué esperás?" value={title} onChangeText={(v) => { setTitle(v); setError(null); }} placeholder="Ej.: Viaje a Córdoba" error={error} autoFocus={!id} maxLength={60} />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <DateField label="Fecha" value={date} onChange={setDate} clearable={false} minimumDate={new Date()} placeholder="Elegir fecha" />
        <TimeField label="Hora (opcional)" value={time} onChange={setTime} placeholder="Todo el día" />
      </View>

      {!id && events.length ? (
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>O usá un evento de tu calendario</T>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {events.map((e) => (
              <Pressable key={e.id} onPress={() => applyEvent(e)} style={{ paddingHorizontal: 12, height: 36, borderRadius: 18, backgroundColor: t.c.surface2, borderWidth: 1, borderColor: t.c.border, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 6 }}>
                <Icon name={e.type === 'birthday' ? 'Cake' : 'CalendarDays'} size={14} color={t.accent.base} />
                <T variant="small" secondary numberOfLines={1}>{e.type === 'birthday' ? `Cumple de ${e.title}` : e.title}</T>
              </Pressable>
            ))}
          </View>
        </View>
      ) : null}

      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Ícono</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {COUNTDOWN_ICONS.map((i) => (
            <Pressable key={i.icon} onPress={() => setIcon(i.icon)} accessibilityLabel={i.label} style={{ width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: icon === i.icon ? color + '2E' : t.c.surface2, borderWidth: 1, borderColor: icon === i.icon ? color : t.c.border }}>
              <Icon name={i.icon} size={22} color={icon === i.icon ? color : t.c.textSecondary} />
            </Pressable>
          ))}
        </View>
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Color</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {['#A78BFA', ...CATEGORY_COLORS].map((c) => (
            <Pressable key={c} onPress={() => setColor(c)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: c, borderWidth: 3, borderColor: color === c ? t.c.text : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
              {color === c ? <Icon name="Check" size={16} color="#fff" strokeWidth={3} /> : null}
            </Pressable>
          ))}
        </View>
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Aviso</T>
        <ChipGroup options={REMIND_OPTIONS} value={remind} onChange={setRemind} />
      </View>
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="Pin" title="Mostrar en el inicio" subtitle="La más cercana de las fijadas aparece grande" value={pinned} onChange={setPinned} />
      </Card>
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
