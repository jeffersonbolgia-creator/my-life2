import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, Image, Linking, Pressable, RefreshControl, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Chip, EmptyState, IconButton, T } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { discoverRepo } from '../../db/repos';
import { adjustWeight, rankItems, topicDef, topicsFromInterests } from '../../logic/discover';
import { isStale, refreshDiscover } from '../../services/discoverService';
import { tap, toast } from '../../ui/haptics';
import type { DiscoverItem } from '../../types';

function timeAgo(iso: string): string {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return '';
  const m = Math.round((Date.now() - t) / 60000);
  if (m < 60) return `hace ${Math.max(1, m)} min`;
  const h = Math.round(m / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.round(h / 24);
  return d === 1 ? 'ayer' : `hace ${d} días`;
}

export function DiscoverCard({ item, big, onOpen, onSave, onHide, onLess }: { item: DiscoverItem; big?: boolean; onOpen: () => void; onSave: () => void; onHide: () => void; onLess: () => void }) {
  const t = useTheme();
  const def = topicDef(item.topic);
  const [broken, setBroken] = useState(false);
  const img = item.imageUrl && !broken ? item.imageUrl : null;
  const placeholder = (h: number) => (
    <View style={{ height: h, backgroundColor: def.color + (t.dark ? '1C' : '14'), alignItems: 'center', justifyContent: 'center' }}>
      <Icon name={def.icon} size={big ? 40 : 28} color={def.color} />
    </View>
  );
  return (
    <Pressable onPress={onOpen} style={({ pressed }) => ({ borderRadius: t.radius.lg, backgroundColor: t.c.surface, borderWidth: 1, borderColor: t.c.border, overflow: 'hidden', opacity: pressed ? 0.85 : 1, flexDirection: big ? 'column' : 'row' })} accessibilityRole="link" accessibilityLabel={item.title}>
      {big ? (
        img ? <Image source={{ uri: img }} style={{ width: '100%', height: 170 }} resizeMode="cover" onError={() => setBroken(true)} /> : placeholder(150)
      ) : (
        <View style={{ width: 96, alignSelf: 'stretch' }}>
          {img ? <Image source={{ uri: img }} style={{ width: 96, height: '100%', minHeight: 96 }} resizeMode="cover" onError={() => setBroken(true)} /> : placeholder(96)}
        </View>
      )}
      <View style={{ flex: 1, padding: 12, gap: 6 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <T variant="small" color={def.color} style={{ letterSpacing: 0.8, textTransform: 'uppercase' }}>{item.topic}</T>
          <T variant="small" muted>· {timeAgo(item.publishedAt)}</T>
        </View>
        <T variant={big ? 'heading' : 'bodyStrong'} numberOfLines={big ? 3 : 3}>{item.title}</T>
        {big && item.summary ? <T variant="caption" secondary numberOfLines={2}>{item.summary}</T> : null}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 }}>
          <T variant="small" muted numberOfLines={1} style={{ flex: 1 }}>{item.source || 'Fuente'}</T>
          <View style={{ flexDirection: 'row', gap: 4 }}>
            <IconButton icon={item.saved ? 'BookmarkCheck' : 'Bookmark'} label={item.saved ? 'Quitar de guardados' : 'Guardar'} size={32} color={item.saved ? t.accent.base : undefined} onPress={onSave} />
            <IconButton icon="ThumbsDown" label="Menos de esto" size={32} onPress={onLess} />
            <IconButton icon="EyeOff" label="Ocultar" size={32} onPress={onHide} />
          </View>
        </View>
      </View>
    </Pressable>
  );
}

export default function DiscoverScreen({ navigation }: any) {
  const t = useTheme();
  const insets = useSafeAreaInsets();
  const profile = useProfile();
  const { updateSettings } = useApp();
  const prefs = profile.settings.discover;
  const [items, setItems] = useState<DiscoverItem[]>([]);
  const [tab, setTab] = useState<'feed' | 'saved'>('feed');
  const [topic, setTopic] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  const load = useCallback(async () => {
    setItems(tab === 'saved' ? await discoverRepo.saved(profile.id) : await discoverRepo.list(profile.id));
  }, [profile.id, tab]);

  const refresh = useCallback(async (silent = false) => {
    if (!prefs.topics.length) return;
    if (!silent) setLoading(true);
    const r = await refreshDiscover(profile.id);
    setStatus(r.error ? 'Sin conexión. Se muestra lo último guardado.' : r.failedTopics.length ? `No se pudo actualizar: ${r.failedTopics.join(', ')}` : r.added ? `${r.added} novedades` : null);
    await load();
    setLoading(false);
  }, [prefs.topics.length, profile.id, load]);

  // Primera vez: proponemos los intereses de la bienvenida
  useEffect(() => {
    if (!prefs.topics.length) {
      const fromInterests = topicsFromInterests(profile.answers.interests ?? []);
      if (fromInterests.length) updateSettings({ discover: { ...prefs, topics: fromInterests } });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    load();
    (async () => {
      if (prefs.topics.length && (await isStale(profile.id))) refresh(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load, prefs.topics.join('|')]);

  const ranked = useMemo(() => {
    const list = tab === 'saved' ? items : rankItems(items, prefs.weights);
    return topic ? list.filter((i) => i.topic === topic) : list;
  }, [items, prefs.weights, tab, topic]);

  const open = async (it: DiscoverItem) => {
    tap();
    await discoverRepo.setFlag(profile.id, it.id, 'opened', true);
    updateSettings({ discover: { ...prefs, weights: adjustWeight(prefs.weights, it.topic, 1) } });
    Linking.openURL(it.url).catch(() => toast('No se pudo abrir el enlace'));
  };
  const save = async (it: DiscoverItem) => {
    await discoverRepo.setFlag(profile.id, it.id, 'saved', !it.saved);
    if (!it.saved) updateSettings({ discover: { ...prefs, weights: adjustWeight(prefs.weights, it.topic, 2) } });
    toast(it.saved ? 'Quitado de guardados' : 'Guardado para después');
    load();
  };
  const hide = async (it: DiscoverItem) => {
    await discoverRepo.setFlag(profile.id, it.id, 'hidden', true);
    load();
  };
  const less = async (it: DiscoverItem) => {
    await discoverRepo.setFlag(profile.id, it.id, 'hidden', true);
    updateSettings({ discover: { ...prefs, weights: adjustWeight(prefs.weights, it.topic, -2) } });
    toast(`Vas a ver menos de ${it.topic}`);
    load();
  };

  const header = (
    <View style={{ gap: 12, paddingBottom: 12 }}>
      <View style={{ flexDirection: 'row', gap: 8 }}>
        <Chip label="Para vos" icon="Compass" selected={tab === 'feed'} onPress={() => { setTab('feed'); setTopic(null); }} />
        <Chip label="Guardados" icon="Bookmark" selected={tab === 'saved'} onPress={() => { setTab('saved'); setTopic(null); }} />
      </View>
      {prefs.topics.length ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          <Chip label="Todo" selected={topic === null} onPress={() => setTopic(null)} />
          {prefs.topics.map((tp) => <Chip key={tp} label={tp} icon={topicDef(tp).icon} color={topicDef(tp).color} selected={topic === tp} onPress={() => setTopic(topic === tp ? null : tp)} />)}
        </View>
      ) : null}
      {status ? <T variant="small" muted>{status}</T> : null}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: t.c.bg }}>
      <View style={{ paddingTop: insets.top + 8, paddingHorizontal: 18, paddingBottom: 12, flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <IconButton icon="ChevronLeft" label="Volver" onPress={() => navigation.goBack()} />
        <View style={{ flex: 1 }}>
          <T variant="heading">Descubrir</T>
          <T variant="caption" secondary numberOfLines={1}>{prefs.topics.length ? `${prefs.topics.length} ${prefs.topics.length === 1 ? 'tema' : 'temas'} · se actualiza solo cada día` : 'Elegí tus intereses'}</T>
        </View>
        <IconButton icon="SlidersHorizontal" label="Intereses" onPress={() => navigation.navigate('DiscoverInterests')} />
      </View>
      {!prefs.topics.length ? (
        <View style={{ flex: 1, paddingHorizontal: 18 }}>
          <EmptyState icon="Compass" title="¿Qué te interesa?" text="Elegí tus temas y cada día vas a tener cosas nuevas para leer. Solo de lo que te gusta, sin likes ni comentarios." action="Elegir intereses" onAction={() => navigation.navigate('DiscoverInterests')} />
        </View>
      ) : (
        <FlatList
          data={ranked}
          keyExtractor={(it) => String(it.id)}
          renderItem={({ item, index }) => (
            <View style={{ marginBottom: 12 }}>
              <DiscoverCard item={item} big={tab === 'feed' && index === 0 && topic === null} onOpen={() => open(item)} onSave={() => save(item)} onHide={() => hide(item)} onLess={() => less(item)} />
            </View>
          )}
          ListHeaderComponent={header}
          ListEmptyComponent={
            tab === 'saved' ? (
              <EmptyState icon="Bookmark" title="Nada guardado todavía" text="Tocá el marcador en una publicación para leerla después." />
            ) : loading ? (
              <EmptyState icon="Compass" title="Buscando novedades…" text="Un momento." />
            ) : (
              <EmptyState icon="WifiOff" title="Todavía no hay publicaciones" text="Conectate a internet y deslizá hacia abajo para traer lo nuevo." action="Actualizar ahora" onAction={() => refresh()} />
            )
          }
          ListFooterComponent={ranked.length ? <View style={{ alignItems: 'center', paddingVertical: 10 }}><Button title="Buscar más novedades" variant="ghost" size="sm" full={false} icon="RefreshCw" onPress={() => refresh()} /></View> : null}
          contentContainerStyle={{ paddingHorizontal: 18, paddingBottom: insets.bottom + 40 }}
          refreshControl={<RefreshControl refreshing={loading} onRefresh={() => refresh()} tintColor={t.accent.base} colors={[t.accent.base]} />}
          initialNumToRender={6}
          windowSize={7}
          removeClippedSubviews
        />
      )}
    </View>
  );
}
