import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Card, ChipGroup, DateField, Field, FormActions, IconButton, ProgressBar, Screen, Segmented, T, ToggleRow } from '../../ui/kit';
import { dollarRepo, goalsRepo, goalProgress } from '../../db/repos';
import type { DollarCasa, DollarRate, GoalTerm } from '../../types';
import { success, toast } from '../../ui/haptics';
import { formatMoney, parseAmount } from '../../lib/money';
import { CASA_LABELS, formatPesos } from '../../logic/dollar';
import { isModuleOn } from '../../modules/registry';

export default function GoalFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [term, setTerm] = useState<GoalTerm>('short');
  const [targetDate, setTargetDate] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [isSaving, setIsSaving] = useState(false);
  const [target, setTarget] = useState('');
  const [saved, setSaved] = useState('');
  const [currency, setCurrency] = useState<'ARS' | 'USD'>('ARS');
  const [casa, setCasa] = useState<DollarCasa>(profile.settings.dollarCasa);
  const [rates, setRates] = useState<DollarRate[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const dollarOn = isModuleOn(profile.settings.modules, 'dollar');

  useEffect(() => {
    dollarRepo.latest().then(setRates).catch(() => {});
    if (!id) return;
    goalsRepo.get(profile.id, id).then((g) => {
      if (!g) return;
      setTitle(g.title);
      setDescription(g.description);
      setTerm(g.term);
      setTargetDate(g.targetDate);
      setProgress(g.progress);
      if (g.savingTarget) {
        setIsSaving(true);
        setTarget(String(g.savingTarget / 100).replace('.', ','));
        setSaved(String(g.savingSaved / 100).replace('.', ','));
        setCurrency(g.savingCurrency);
        if (g.savingCasa) setCasa(g.savingCasa);
      }
    });
  }, [id, profile.id]);

  const targetCents = isSaving ? parseAmount(target) ?? 0 : 0;
  const savedCents = isSaving ? parseAmount(saved) ?? 0 : 0;
  const usd = rates.find((r) => r.casa === casa) ?? null;
  const toArs = (cents: number) => (currency === 'USD' && usd ? Math.round(cents * usd.sell) : cents);
  const effectiveProgress = isSaving && targetCents > 0 ? goalProgress({ progress, savingTarget: targetCents, savingSaved: savedCents }) : progress;

  const save = async () => {
    if (!title.trim()) return setError('Escribí tu objetivo');
    if (isSaving && targetCents <= 0) return Alert.alert('Meta de ahorro', '¿Cuánto querés juntar?');
    setSaving(true);
    const data = {
      title: title.trim(), description: description.trim(), term, targetDate, progress,
      savingTarget: isSaving ? targetCents : null, savingSaved: isSaving ? savedCents : 0, savingCurrency: currency, savingCasa: isSaving && currency === 'USD' ? casa : null,
    };
    try {
      if (id) await goalsRepo.update(profile.id, id, data);
      else await goalsRepo.create(profile.id, data);
      success();
      toast(effectiveProgress >= 100 ? '¡Objetivo alcanzado!' : 'Objetivo guardado');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar objetivo', '¿Seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await goalsRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  const setP = (v: number) => setProgress(Math.max(0, Math.min(100, Math.round(v))));

  return (
    <Screen title={id ? 'Editar objetivo' : 'Nuevo objetivo'} back>
      <Field label="Objetivo" value={title} onChangeText={(v) => { setTitle(v); setError(null); }} placeholder="Ej.: Ahorrar para una bici" error={error} autoFocus={!id} maxLength={100} />
      <Field label="Descripción (opcional)" value={description} onChangeText={setDescription} multiline placeholder="¿Por qué es importante? ¿Cómo lo vas a lograr?" />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Plazo</T>
        <Segmented value={term} onChange={setTerm} options={[{ value: 'short', label: 'Corto plazo' }, { value: 'long', label: 'Largo plazo' }]} />
      </View>
      <DateField label="Fecha límite (opcional)" value={targetDate} onChange={setTargetDate} placeholder="Sin fecha límite" />
      <Card padding={0} style={{ paddingHorizontal: 14 }}>
        <ToggleRow icon="PiggyBank" title="Es una meta de ahorro" subtitle="El progreso sale de lo que vas juntando" value={isSaving} onChange={setIsSaving} />
      </Card>
      {isSaving ? (
        <Card>
          <View style={{ gap: 12 }}>
            <Segmented<'ARS' | 'USD'> value={currency} onChange={setCurrency} options={[{ value: 'ARS', label: 'En pesos' }, { value: 'USD', label: 'En dólares' }]} />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <Field label="Quiero juntar" value={target} onChangeText={setTarget} keyboardType="decimal-pad" placeholder="0" prefix={currency === 'USD' ? 'US$' : '$'} style={{ flex: 1 }} />
              <Field label="Ya tengo" value={saved} onChangeText={setSaved} keyboardType="decimal-pad" placeholder="0" prefix={currency === 'USD' ? 'US$' : '$'} style={{ flex: 1 }} />
            </View>
            {currency === 'USD' ? (
              <View style={{ gap: 8 }}>
                <T variant="caption" secondary>Convertir a pesos con</T>
                <ChipGroup options={(['blue', 'oficial', 'bolsa', 'tarjeta'] as DollarCasa[]).map((c) => ({ value: c, label: CASA_LABELS[c].short }))} value={casa} onChange={setCasa} />
                {usd ? (
                  <T variant="caption" secondary>
                    {targetCents > 0 ? `Objetivo ≈ ${formatMoney(toArs(targetCents))} · ` : ''}Ahorrado ≈ {formatMoney(toArs(savedCents))} ({CASA_LABELS[casa].short} a {formatPesos(usd.sell)})
                  </T>
                ) : (
                  <T variant="small" muted>{dollarOn ? 'Abrí "Dólar hoy" con internet para tener la cotización.' : 'Activá el módulo "Dólar hoy" para convertir a pesos.'}</T>
                )}
              </View>
            ) : null}
            {targetCents > 0 ? (
              <View style={{ gap: 6 }}>
                <ProgressBar value={effectiveProgress} height={10} color={effectiveProgress >= 100 ? t.c.success : undefined} />
                <T variant="caption" secondary>{effectiveProgress}% · faltan {currency === 'USD' ? `US$ ${Math.max(0, (targetCents - savedCents) / 100).toFixed(0)}` : formatMoney(Math.max(0, targetCents - savedCents))}</T>
              </View>
            ) : null}
          </View>
        </Card>
      ) : (
      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <T variant="bodyStrong">Progreso</T>
          <T variant="title" color={progress >= 100 ? t.c.success : t.accent.base}>{progress}%</T>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 14 }}>
          <IconButton icon="Minus" label="Restar 5%" size={38} onPress={() => setP(progress - 5)} />
          <View style={{ flex: 1 }}><ProgressBar value={progress} height={10} color={progress >= 100 ? t.c.success : undefined} /></View>
          <IconButton icon="Plus" label="Sumar 5%" size={38} filled onPress={() => setP(progress + 5)} />
        </View>
        <ChipGroup options={[0, 25, 50, 75, 100].map((v) => ({ value: v, label: `${v}%` }))} value={progress} onChange={setP} />
        {progress >= 100 ? <T variant="small" color={t.c.success} style={{ marginTop: 10 }}>Al guardar se marcará como alcanzado.</T> : null}
      </Card>
      )}
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
