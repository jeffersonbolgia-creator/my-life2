import React, { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { Button, Field, FormActions, IconButton, Screen, Segmented, T, TimeField } from '../../ui/kit';
import { DayPicker } from '../../ui/DayPicker';
import { Icon } from '../../ui/Icon';
import { habitsRepo } from '../../db/repos';
import { CATEGORY_COLORS } from '../../theme/theme';
import type { HabitFrequency } from '../../types';
import { success, toast } from '../../ui/haptics';

const ICONS = ['Sparkles', 'Droplets', 'BookOpen', 'Dumbbell', 'Moon', 'Brain', 'GraduationCap', 'Footprints', 'Smartphone', 'House', 'Wallet', 'Apple', 'Heart', 'Music', 'Bike', 'Code', 'Languages', 'Pill', 'Sun', 'Leaf'];

export default function HabitFormScreen({ navigation, route }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [title, setTitle] = useState('');
  const [frequency, setFrequency] = useState<HabitFrequency>('daily');
  const [weekdays, setWeekdays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [target, setTarget] = useState(3);
  const [reminder, setReminder] = useState<string | null>(null);
  const [icon, setIcon] = useState('Sparkles');
  const [color, setColor] = useState(CATEGORY_COLORS[0]);
  const [archived, setArchived] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    habitsRepo.get(profile.id, id).then((h) => {
      if (!h) return;
      setTitle(h.title);
      setFrequency(h.frequency);
      setWeekdays(h.weekdays.length ? h.weekdays : [0, 1, 2, 3, 4, 5, 6]);
      setTarget(h.targetPerWeek);
      setReminder(h.reminderTime);
      setIcon(h.icon);
      setColor(h.color);
      setArchived(h.archived);
    });
  }, [id, profile.id]);

  const save = async () => {
    if (!title.trim()) return setError('Escribí el hábito');
    if (frequency === 'daily' && weekdays.length === 0) return Alert.alert('Días', 'Elegí al menos un día.');
    setSaving(true);
    const data = {
      title: title.trim(),
      frequency,
      weekdays: frequency === 'daily' && weekdays.length < 7 ? weekdays : [],
      targetPerWeek: target,
      reminderTime: reminder,
      color,
      icon,
    };
    try {
      if (id) await habitsRepo.update(profile.id, id, data);
      else await habitsRepo.create(profile.id, data);
      success();
      toast('Hábito guardado');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar hábito', 'Se borrará también todo su historial. Si sólo querés pausarlo, archivalo.', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await habitsRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  const toggleArchive = async () => {
    await habitsRepo.setArchived(profile.id, id!, !archived);
    toast(archived ? 'Hábito reactivado' : 'Hábito archivado');
    bump();
    navigation.goBack();
  };

  return (
    <Screen title={id ? 'Editar hábito' : 'Nuevo hábito'} back>
      <Field label="Hábito" value={title} onChangeText={(v) => { setTitle(v); setError(null); }} placeholder="Ej.: Leer 20 minutos" error={error} autoFocus={!id} maxLength={60} />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Frecuencia</T>
        <Segmented value={frequency} onChange={setFrequency} options={[{ value: 'daily', label: 'Rutina diaria' }, { value: 'weekly', label: 'Veces por semana' }]} />
      </View>
      {frequency === 'daily' ? (
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>¿Qué días?</T>
          <DayPicker value={weekdays} onChange={setWeekdays} />
        </View>
      ) : (
        <View style={{ gap: 8 }}>
          <T variant="caption" secondary>Objetivo semanal</T>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
            <IconButton icon="Minus" label="Menos" onPress={() => setTarget((v) => Math.max(1, v - 1))} />
            <T variant="title">{target}</T>
            <IconButton icon="Plus" label="Más" filled onPress={() => setTarget((v) => Math.min(7, v + 1))} />
            <T secondary>veces por semana</T>
          </View>
        </View>
      )}
      <TimeField label="Recordatorio (opcional)" value={reminder} onChange={setReminder} placeholder="Sin recordatorio" />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Ícono</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {ICONS.map((i) => (
            <Pressable key={i} onPress={() => setIcon(i)} style={{ width: 48, height: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: icon === i ? color + '2E' : t.c.surface2, borderWidth: 1, borderColor: icon === i ? color : t.c.border }}>
              <Icon name={i} size={22} color={icon === i ? color : t.c.textSecondary} />
            </Pressable>
          ))}
        </View>
      </View>
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Color</T>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {CATEGORY_COLORS.map((c) => (
            <Pressable key={c} onPress={() => setColor(c)} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: c, borderWidth: 3, borderColor: color === c ? t.c.text : 'transparent', alignItems: 'center', justifyContent: 'center' }}>
              {color === c ? <Icon name="Check" size={16} color="#fff" strokeWidth={3} /> : null}
            </Pressable>
          ))}
        </View>
      </View>
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
      {id ? <Button title={archived ? 'Reactivar hábito' : 'Archivar hábito'} icon="Archive" variant="secondary" onPress={toggleArchive} /> : null}
    </Screen>
  );
}
