import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Card, EmptyState, IconButton, Screen, SectionHeader, T, Badge } from '../../ui/kit';
import { Icon } from '../../ui/Icon';
import { habitsRepo } from '../../db/repos';
import { addDays, parseISODate, todayISO, WEEKDAYS_SHORT, formatRelativeDay } from '../../lib/dates';
import { bestStreak, completionRate, currentStreak, isScheduledOn, weekProgress } from '../../logic/habits';
import type { Habit } from '../../types';
import { success, tap } from '../../ui/haptics';

function describe(h: Habit): string {
  if (h.frequency === 'weekly') return `${h.targetPerWeek} veces por semana`;
  if (!h.weekdays.length || h.weekdays.length === 7) return 'Todos los días';
  return [1, 2, 3, 4, 5, 6, 0].filter((d) => h.weekdays.includes(d)).map((d) => WEEKDAYS_SHORT[d]).join(', ');
}

export default function HabitsScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { bump } = useApp();
  const today = todayISO();
  const [day, setDay] = useState(today);
  const [showArchived, setShowArchived] = useState(false);
  const { data } = useData(
    async (pid) => ({ habits: await habitsRepo.list(pid, true), logs: await habitsRepo.logs(pid) }),
    { habits: [] as Habit[], logs: new Map<number, Set<string>>() },
  );
  const active = data.habits.filter((h) => !h.archived);
  const archived = data.habits.filter((h) => h.archived);
  const days = Array.from({ length: 7 }, (_, i) => addDays(today, i - 6));

  const toggle = async (h: Habit) => {
    const on = await habitsRepo.toggle(profile.id, h.id, day);
    if (on) success();
    bump();
  };

  const doneOnDay = active.filter((h) => data.logs.get(h.id)?.has(day)).length;
  const scheduledOnDay = active.filter((h) => isScheduledOn(h, day) || h.frequency === 'weekly').length;

  return (
    <Screen title="Hábitos" back right={<IconButton icon="Plus" label="Nuevo hábito" filled onPress={() => navigation.navigate('HabitForm')} />}>
      <View style={{ flexDirection: 'row', gap: 6 }}>
        {days.map((d) => {
          const sel = d === day;
          return (
            <Pressable
              key={d}
              onPress={() => { tap(); setDay(d); }}
              style={{ flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 14, gap: 3, backgroundColor: sel ? t.accent.base : t.c.surface, borderWidth: 1, borderColor: t.c.border }}
            >
              <T variant="small" color={sel ? '#FFFFFFCC' : t.c.textMuted}>{WEEKDAYS_SHORT[parseISODate(d).getDay()]}</T>
              <T variant="bodyStrong" color={sel ? '#fff' : t.c.text}>{parseISODate(d).getDate()}</T>
            </Pressable>
          );
        })}
      </View>
      <T variant="caption" secondary align="center">
        {formatRelativeDay(day)} · {doneOnDay} de {scheduledOnDay} cumplidos
      </T>

      {active.length === 0 ? (
        <EmptyState icon="Repeat" title="Sin hábitos todavía" text="Los hábitos pequeños, repetidos todos los días, hacen grandes cambios." action="Crear hábito" onAction={() => navigation.navigate('HabitForm')} />
      ) : active.map((h) => {
        const logs = data.logs.get(h.id) ?? new Set<string>();
        const done = logs.has(day);
        const applies = isScheduledOn(h, day) || h.frequency === 'weekly';
        const streak = currentStreak(h, logs, today);
        const best = bestStreak(h, logs, today);
        const rate = completionRate(h, logs, addDays(today, -29), today);
        const wp = weekProgress(h, logs, today);
        const last28 = Array.from({ length: 28 }, (_, i) => addDays(today, i - 27));
        return (
          <Card key={h.id} onPress={() => navigation.navigate('HabitForm', { id: h.id })}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: h.color + (t.dark ? '26' : '1A'), alignItems: 'center', justifyContent: 'center' }}>
                <Icon name={h.icon} size={22} color={h.color} />
              </View>
              <View style={{ flex: 1 }}>
                <T variant="bodyStrong" numberOfLines={1}>{h.title}</T>
                <T variant="small" muted>{describe(h)}{h.reminderTime ? ` · ${h.reminderTime}` : ''}</T>
              </View>
              <Pressable
                onPress={() => { tap(); toggle(h); }}
                hitSlop={8}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: done }}
                style={{ width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: done ? h.color : t.c.surface2, borderWidth: 1, borderColor: done ? h.color : t.c.borderStrong, opacity: applies ? 1 : 0.5 }}
              >
                <Icon name="Check" size={22} color={done ? '#fff' : t.c.textMuted} strokeWidth={2.6} />
              </Pressable>
            </View>
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
              <Badge label={`Racha: ${streak} ${h.frequency === 'weekly' ? 'sem.' : 'días'}`} color="#F97316" />
              <Badge label={`Mejor: ${best}`} color={t.c.textSecondary} />
              <Badge label={`30 días: ${rate}%`} color={h.color} />
              <Badge label={`Semana: ${wp.done}/${wp.target}`} color={t.c.textSecondary} />
            </View>
            <View style={{ flexDirection: 'row', gap: 3, marginTop: 12 }}>
              {last28.map((d) => (
                <View key={d} style={{ flex: 1, height: 10, borderRadius: 3, backgroundColor: logs.has(d) ? h.color : isScheduledOn(h, d) ? t.c.surface3 : t.c.surface2 }} />
              ))}
            </View>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 }}>
              <T variant="small" muted>hace 4 semanas</T>
              <T variant="small" muted>hoy</T>
            </View>
          </Card>
        );
      })}

      {archived.length > 0 && (
        <>
          <SectionHeader title={`Archivados · ${archived.length}`} action={showArchived ? 'Ocultar' : 'Mostrar'} onAction={() => setShowArchived((v) => !v)} />
          {showArchived && archived.map((h) => (
            <Card key={h.id} onPress={() => navigation.navigate('HabitForm', { id: h.id })}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, opacity: 0.6 }}>
                <Icon name={h.icon} size={20} color={h.color} />
                <T style={{ flex: 1 }}>{h.title}</T>
                <Icon name="Archive" size={16} color={t.c.textMuted} />
              </View>
            </Card>
          ))}
        </>
      )}
      <T variant="small" muted align="center">Tocá un día de arriba para marcar hábitos de días anteriores.</T>
    </Screen>
  );
}
