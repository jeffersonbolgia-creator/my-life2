import React, { useEffect, useState } from 'react';
import { Alert, View } from 'react-native';
import { useApp, useProfile } from '../../state/AppContext';
import { ChipGroup, DateField, Field, FormActions, Screen, Segmented, T, TimeField } from '../../ui/kit';
import { remindersRepo } from '../../db/repos';
import { centsToInput, parseAmount } from '../../lib/money';
import { todayISO, minutesToTime, timeToMinutes, timeFromDate } from '../../lib/dates';
import type { ReminderKind, ReminderRepeat } from '../../types';
import { success, toast } from '../../ui/haptics';
import { REPEAT_LABEL } from './RemindersScreen';

export default function ReminderFormScreen({ navigation, route }: any) {
  const profile = useProfile();
  const { bump } = useApp();
  const id: number | undefined = route.params?.id;
  const [kind, setKind] = useState<ReminderKind>(route.params?.kind ?? 'general');
  const pre = route.params?.prefill ?? null;
  const [title, setTitle] = useState<string>(pre?.title ?? '');
  const [date, setDate] = useState<string | null>(pre?.date ?? todayISO());
  const [time, setTime] = useState<string | null>(pre?.time ?? minutesToTime(Math.ceil((timeToMinutes(timeFromDate(new Date())) + 30) / 15) * 15));
  const [repeat, setRepeat] = useState<ReminderRepeat>('none');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) return;
    remindersRepo.get(profile.id, id).then((r) => {
      if (!r) return;
      setKind(r.kind);
      setTitle(r.title);
      setDate(r.date);
      setTime(r.time);
      setRepeat(r.repeat);
      setAmount(r.amount ? centsToInput(r.amount) : '');
      setNotes(r.notes);
    });
  }, [id, profile.id]);

  const save = async () => {
    if (!title.trim()) return setError(kind === 'payment' ? 'Escribí qué tenés que pagar' : 'Escribí el recordatorio');
    if (!date || !time) return Alert.alert('Faltan datos', 'Elegí fecha y hora.');
    const amt = amount.trim() ? parseAmount(amount) : null;
    if (amount.trim() && (amt == null || amt <= 0)) return Alert.alert('Importe', 'El importe no es válido.');
    setSaving(true);
    const data = { title: title.trim(), kind, date, time, repeat, amount: kind === 'payment' ? amt : null, notes: notes.trim() };
    try {
      if (id) await remindersRepo.update(profile.id, id, data);
      else await remindersRepo.create(profile.id, data);
      success();
      toast('Recordatorio guardado');
      bump();
      navigation.goBack();
    } catch (e: any) {
      setSaving(false);
      Alert.alert('Error', String(e?.message ?? e));
    }
  };

  const remove = () =>
    Alert.alert('Eliminar recordatorio', '¿Seguro?', [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: async () => { await remindersRepo.remove(profile.id, id!); bump(); navigation.goBack(); } },
    ]);

  return (
    <Screen title={id ? 'Editar recordatorio' : 'Nuevo recordatorio'} back>
      <Segmented value={kind} onChange={setKind} options={[{ value: 'general', label: 'Recordatorio' }, { value: 'payment', label: 'Pago' }]} />
      <Field
        label={kind === 'payment' ? '¿Qué hay que pagar?' : '¿Qué te recordamos?'}
        value={title}
        onChangeText={(v) => { setTitle(v); setError(null); }}
        placeholder={kind === 'payment' ? 'Ej.: Factura de internet' : 'Ej.: Llamar a la abuela'}
        error={error}
        autoFocus={!id}
      />
      {kind === 'payment' && <Field label="Importe (opcional)" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" prefix="$" placeholder="0" />}
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <DateField label={repeat === 'none' ? 'Fecha' : 'Desde'} value={date} onChange={setDate} clearable={false} />
      </View>
      <TimeField label="Hora del aviso" value={time} onChange={setTime} clearable={false} />
      <View style={{ gap: 8 }}>
        <T variant="caption" secondary>Repetir</T>
        <ChipGroup options={(['none', 'daily', 'weekly', 'monthly'] as ReminderRepeat[]).map((v) => ({ value: v, label: REPEAT_LABEL[v] }))} value={repeat} onChange={setRepeat} />
      </View>
      <Field label="Notas (opcional)" value={notes} onChangeText={setNotes} multiline />
      <FormActions onSave={save} saving={saving} onDelete={id ? remove : undefined} />
    </Screen>
  );
}
