import React, { useMemo } from 'react';
import { Pressable, View } from 'react-native';
import { useApp, useProfile, useTheme } from '../../state/AppContext';
import { useData } from '../../state/useData';
import { Card, EmptyState, IconButton, ProgressRing, Screen, SectionHeader, T } from '../../ui/kit';
import { Donut, Legend } from '../../ui/charts';
import { Icon } from '../../ui/Icon';
import { dollarRepo, subscriptionsRepo } from '../../db/repos';
import { cycleProgress, daysLabel, daysUntilCharge, rolledDate, sortByNext, totals, usdSellFrom, CYCLE_LABELS } from '../../logic/subscriptions';
import { formatMoney } from '../../lib/money';
import { formatRelativeDay } from '../../lib/dates';
import type { DollarRate, Subscription } from '../../types';

export function SubscriptionRow({ s, usdSell, onPress }: { s: Subscription; usdSell: number | null; onPress?: () => void }) {
  const t = useTheme();
  const now = new Date();
  const days = daysUntilCharge(s, now);
  const pct = cycleProgress(s, now);
  const soon = days <= 3;
  const color = !s.active ? t.c.textMuted : soon ? t.c.warning : s.color;
  const amount = s.currency === 'USD' ? `US$ ${(s.amount / 100).toFixed(2).replace('.', ',').replace(',00', '')}` : formatMoney(s.amount);
  const ars = s.currency === 'USD' && usdSell ? `≈ ${formatMoney(Math.round(s.amount * usdSell))}` : null;
  return (
    <Card onPress={onPress} padding={14} style={!s.active ? { opacity: 0.6 } : undefined}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <ProgressRing value={s.active ? pct : 0} size={56} stroke={5} color={color}>
          <View style={{ alignItems: 'center' }}>
            <T variant="heading" style={{ lineHeight: 20 }}>{s.active ? (days < 0 ? '!' : days) : '—'}</T>
            <T variant="small" muted style={{ fontSize: 9, lineHeight: 11 }}>{s.active ? (days === 1 ? 'día' : 'días') : 'pausa'}</T>
          </View>
        </ProgressRing>
        <View style={{ flex: 1, gap: 3 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Icon name={s.icon} size={16} color={s.color} />
            <T variant="bodyStrong" numberOfLines={1} style={{ flex: 1 }}>{s.name}</T>
          </View>
          <T variant="small" secondary>{CYCLE_LABELS[s.cycle]} · {s.active ? `${daysLabel(s, now)} · ${formatRelativeDay(s.nextDate)}` : 'En pausa'}</T>
        </View>
        <View style={{ alignItems: 'flex-end' }}>
          <T variant="bodyStrong">{amount}</T>
          <T variant="small" muted>{ars ?? (s.currency === 'USD' ? 'USD' : s.cycle === 'monthly' ? 'por mes' : CYCLE_LABELS[s.cycle].toLowerCase())}</T>
        </View>
      </View>
    </Card>
  );
}

async function load(pid: number) {
  const [subs, rates] = await Promise.all([subscriptionsRepo.list(pid), dollarRepo.latest()]);
  // Renovación automática de los cobros que ya pasaron
  for (const s of subs) {
    if (!s.active) continue;
    const rolled = rolledDate(s);
    if (rolled) {
      await subscriptionsRepo.setNextDate(pid, s.id, rolled);
      s.nextDate = rolled;
    }
  }
  return { subs: sortByNext(subs), rates };
}

export default function SubscriptionsScreen({ navigation }: any) {
  const t = useTheme();
  const profile = useProfile();
  const { data } = useData<{ subs: Subscription[]; rates: DollarRate[] }>(load, { subs: [], rates: [] });
  const usdSell = usdSellFrom(data.rates, 'tarjeta');
  const tot = useMemo(() => totals(data.subs, usdSell), [data.subs, usdSell]);
  const next = data.subs.find((s) => s.active) ?? null;
  const active = data.subs.filter((s) => s.active);
  const paused = data.subs.filter((s) => !s.active);

  return (
    <Screen title="Suscripciones" back right={<IconButton icon="Plus" label="Nueva suscripción" filled onPress={() => navigation.navigate('SubscriptionForm')} />}>
      {data.subs.length === 0 ? (
        <EmptyState icon="Repeat2" title="Tus gastos fijos, bajo control" text="Cargá tus suscripciones y servicios: te mostramos cuántos días faltan para cada cobro y cuánto se te va por mes." action="Agregar la primera" onAction={() => navigation.navigate('SubscriptionForm')} />
      ) : (
        <>
          <Card gradient accentBorder>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
              <Donut size={96} stroke={14} data={tot.byCategory.map((c) => ({ value: c.amountArs, color: c.color }))}>
                <View style={{ alignItems: 'center' }}>
                  <T variant="heading">{tot.count}</T>
                  <T variant="small" muted>activas</T>
                </View>
              </Donut>
              <View style={{ flex: 1, gap: 4 }}>
                <T variant="label" muted>Por mes</T>
                <T variant="display" style={{ fontSize: 30, lineHeight: 36 }}>{formatMoney(tot.monthlyArs, profile.settings.currency)}</T>
                {tot.monthlyUsd ? (
                  <T variant="caption" secondary>
                    Incluye US$ {(tot.monthlyUsd / 100).toFixed(0)} {usdSell ? 'al dólar tarjeta' : '(sin cotización todavía)'}
                  </T>
                ) : null}
                {next ? <T variant="caption" color={daysUntilCharge(next) <= 3 ? t.c.warning : t.c.textSecondary}>{daysLabel(next)}: {next.name}</T> : null}
              </View>
            </View>
            {tot.byCategory.length > 1 ? (
              <View style={{ marginTop: 14 }}>
                <Legend items={tot.byCategory.slice(0, 5).map((c) => ({ color: c.color, label: `${c.category} ${formatMoney(c.amountArs)}` }))} />
              </View>
            ) : null}
          </Card>

          <SectionHeader title="Próximos cobros" />
          {active.map((s) => <SubscriptionRow key={s.id} s={s} usdSell={usdSell} onPress={() => navigation.navigate('SubscriptionForm', { id: s.id })} />)}
          {paused.length ? (
            <>
              <SectionHeader title="En pausa" />
              {paused.map((s) => <SubscriptionRow key={s.id} s={s} usdSell={usdSell} onPress={() => navigation.navigate('SubscriptionForm', { id: s.id })} />)}
            </>
          ) : null}
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'flex-start', paddingHorizontal: 4 }}>
            <Icon name="Info" size={14} color={t.c.textMuted} />
            <T variant="small" muted style={{ flex: 1 }}>Si registrás el pago en Finanzas con el mismo nombre, la suscripción se renueva sola. Cuando llega la fecha, pasa al ciclo siguiente.</T>
          </View>
        </>
      )}
    </Screen>
  );
}
