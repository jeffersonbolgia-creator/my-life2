// Trae las noticias de los temas de un perfil y las guarda en el celular.
// Solo se envía el tema a buscar; nunca datos del usuario.

import { discoverRepo, profilesRepo } from '../db/repos';
import { newsFeedUrl, parseRss, splitSourceFromTitle, topicDef } from '../logic/discover';
import type { DiscoverItemInput } from '../db/repos';

const PER_TOPIC = 12;

async function fetchText(url: string, timeoutMs = 12000): Promise<string> {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { signal: ctrl?.signal, headers: { Accept: 'application/rss+xml, application/xml, text/xml, */*' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.text();
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export interface DiscoverRefresh {
  ok: boolean;
  added: number;
  failedTopics: string[];
  error?: string;
}

/** Trae lo nuevo de cada tema del perfil. Si no hay temas, no hace nada. */
export async function refreshDiscover(pid: number): Promise<DiscoverRefresh> {
  const profile = await profilesRepo.get(pid);
  if (!profile) return { ok: false, added: 0, failedTopics: [], error: 'Perfil inexistente' };
  const topics = profile.settings.discover.topics;
  if (!topics.length) return { ok: true, added: 0, failedTopics: [] };
  let added = 0;
  const failed: string[] = [];
  for (const topic of topics) {
    const def = topicDef(topic);
    try {
      const xml = await fetchText(newsFeedUrl(def.query));
      const items = parseRss(xml).slice(0, PER_TOPIC);
      const inputs: DiscoverItemInput[] = items.map((it) => {
        const { title, source } = splitSourceFromTitle(it.title, it.source);
        return { topic, title, summary: it.summary, url: it.link, source, imageUrl: it.imageUrl, publishedAt: it.publishedAt };
      });
      added += await discoverRepo.addMany(pid, inputs);
    } catch {
      failed.push(topic);
    }
  }
  await discoverRepo.prune(pid, 300, topics);
  return { ok: failed.length < topics.length, added, failedTopics: failed, error: failed.length === topics.length ? 'No se pudo conectar' : undefined };
}

/** ¿Pasaron más de `hours` horas desde la última actualización? */
export async function isStale(pid: number, hours = 6): Promise<boolean> {
  const last = await discoverRepo.lastFetch(pid);
  if (!last) return true;
  const t = new Date(last.replace(' ', 'T')).getTime();
  return !Number.isFinite(t) || Date.now() - t > hours * 3600_000;
}
