import { useCallback, useEffect, useRef, useState } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { useApp } from './AppContext';

/**
 * Carga datos del perfil activo y los vuelve a cargar cuando:
 * - cambia algún dato (bump), o
 * - la pantalla vuelve a estar visible.
 */
export function useData<T>(loader: (pid: number) => Promise<T>, initial: T, deps: unknown[] = []): { data: T; loading: boolean; reload: () => void } {
  const { profile, dataVersion } = useApp();
  const [data, setData] = useState<T>(initial);
  const [loading, setLoading] = useState(true);
  const alive = useRef(true);
  const pid = profile?.id;

  const load = useCallback(() => {
    if (pid == null) return;
    loader(pid)
      .then((d) => {
        if (alive.current) setData(d);
      })
      .catch((e) => console.warn('useData', e))
      .finally(() => {
        if (alive.current) setLoading(false);
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pid, dataVersion, ...deps]);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  // useFocusEffect vuelve a ejecutarse cuando la pantalla recibe foco y cuando cambia `load`.
  useFocusEffect(load);

  return { data, loading, reload: load };
}
