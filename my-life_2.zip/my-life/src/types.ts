import type { CurrencyCode } from './lib/money';

export type ThemeMode = 'dark' | 'light' | 'system';
export type AccentKey = 'violet' | 'indigo' | 'fuchsia' | 'blue' | 'emerald' | 'amber' | 'rose';

export type DashboardCardKey =
  | 'today'
  | 'routine'
  | 'countdown'
  | 'dollar'
  | 'subscriptions'
  | 'discover'
  | 'tasks'
  | 'events'
  | 'reminders'
  | 'habits'
  | 'goals'
  | 'finance'
  | 'weekly';

/** Módulos que cada perfil puede encender o apagar. */
export type ModuleKey = 'countdown' | 'routines' | 'dollar' | 'subscriptions' | 'discover' | 'assistant';

export type GlowLevel = 'off' | 'soft' | 'strong';
export type BgStyle = 'pure' | 'gradient' | 'nebula';
export type RadiusStyle = 'sharp' | 'soft' | 'round';
export type FontScale = 'small' | 'normal' | 'large';

export interface NotificationSettings {
  enabled: boolean;
  tasks: boolean;
  events: boolean;
  habits: boolean;
  payments: boolean;
  reminders: boolean;
  goals: boolean;
  dailySummary: boolean;
  dailySummaryTime: string; // HH:mm
  defaultTime: string; // hora para avisos sin horario
  discreet: boolean; // ocultar el contenido en la notificación
}

export interface ProfileSettings {
  themeMode: ThemeMode;
  accent: AccentKey;
  gradients: boolean;
  haptics: boolean;
  compact: boolean;
  dashboardCards: { key: DashboardCardKey; visible: boolean }[];
  showWeeklySummary: boolean;
  showMonthlySummary: boolean;
  autoLockMinutes: number; // 0 = inmediato, -1 = nunca
  biometrics: boolean;
  pinLength: 4 | 6;
  notifications: NotificationSettings;
  currency: CurrencyCode;
  initialBalance: number; // centavos
  initialBalanceDate: string | null;
  /** Módulos activos de este perfil. */
  modules: Record<ModuleKey, boolean>;
  /** Dólar que se muestra por defecto. */
  dollarCasa: DollarCasa;
  discover: { topics: string[]; weights: Record<string, number>; wifiOnly: boolean };
  assistant: { name: string; personality: AssistantPersonality; proactive: boolean };
  glow: GlowLevel;
  bgStyle: BgStyle;
  radiusStyle: RadiusStyle;
  fontScale: FontScale;
}

export interface ProfileAnswers {
  studiesAtSchool?: boolean;
  schoolLevel?: string;
  studies?: boolean;
  studyWhat?: string;
  works?: boolean;
  workWhat?: string;
  activities?: string[];
  interests?: string[];
  goals?: string[];
  habitsToImprove?: string[];
  wakeTime?: string;
  sleepTime?: string;
  scheduleDays?: number[];
  scheduleStart?: string;
  scheduleEnd?: string;
}

export interface Profile {
  id: number;
  name: string;
  birthDate: string | null;
  age: number | null;
  avatarColor: string;
  answers: ProfileAnswers;
  settings: ProfileSettings;
  securityQuestion: string;
  createdAt: string;
}

export type Priority = 0 | 1 | 2; // baja, media, alta

export interface Task {
  id: number;
  profileId: number;
  title: string;
  description: string;
  dueDate: string | null;
  dueTime: string | null;
  priority: Priority;
  category: string;
  remindMinutes: number | null; // null = sin aviso; 0 = a la hora
  completedAt: string | null;
  createdAt: string;
}

export type EventType = 'event' | 'appointment' | 'birthday' | 'important' | 'schedule';
export type Recurrence = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface CalendarEvent {
  id: number;
  profileId: number;
  title: string;
  type: EventType;
  date: string;
  startTime: string | null;
  endTime: string | null;
  allDay: boolean;
  recurrence: Recurrence;
  weekdays: number[]; // para recurrencia semanal (0 = domingo)
  untilDate: string | null;
  remindMinutes: number | null;
  location: string;
  notes: string;
  createdAt: string;
}

export type GoalTerm = 'short' | 'long';

export interface Goal {
  id: number;
  profileId: number;
  title: string;
  description: string;
  term: GoalTerm;
  targetDate: string | null;
  progress: number; // 0..100
  completedAt: string | null;
  createdAt: string;
  /** Meta de ahorro (opcional): monto objetivo y ahorrado, en centavos de la moneda indicada. */
  savingTarget: number | null;
  savingSaved: number;
  savingCurrency: 'ARS' | 'USD';
  savingCasa: DollarCasa | null; // qué dólar usar para convertir a pesos
}

export type HabitFrequency = 'daily' | 'weekly';

export interface Habit {
  id: number;
  profileId: number;
  title: string;
  frequency: HabitFrequency;
  weekdays: number[]; // para 'daily': días en que aplica (vacío = todos)
  targetPerWeek: number; // para 'weekly'
  reminderTime: string | null;
  color: string;
  icon: string;
  archived: boolean;
  createdAt: string;
}

export interface NoteItem {
  text: string;
  done: boolean;
}

export interface Note {
  id: number;
  profileId: number;
  title: string;
  body: string;
  category: string;
  isList: boolean;
  items: NoteItem[];
  favorite: boolean;
  createdAt: string;
  updatedAt: string;
}

export type TxKind = 'income' | 'expense';

export interface Transaction {
  id: number;
  profileId: number;
  kind: TxKind;
  name: string;
  emoji: string;
  category: string;
  quantity: number;
  unitPrice: number | null; // centavos
  amount: number; // centavos, siempre positivo
  date: string;
  description: string;
  createdAt: string;
}

export type ReminderKind = 'general' | 'payment';
export type ReminderRepeat = 'none' | 'daily' | 'weekly' | 'monthly';

export interface Reminder {
  id: number;
  profileId: number;
  title: string;
  kind: ReminderKind;
  date: string;
  time: string;
  repeat: ReminderRepeat;
  amount: number | null;
  notes: string;
  done: boolean;
  createdAt: string;
}

/** Cuenta regresiva hacia una fecha (viaje, examen, cumpleaños...). */
export interface Countdown {
  id: number;
  profileId: number;
  title: string;
  date: string; // YYYY-MM-DD
  time: string | null; // HH:mm, null = todo el día
  icon: string;
  color: string;
  remindDaysBefore: number | null; // null = sin aviso; 0 = el mismo día
  pinned: boolean; // se muestra en el inicio
  createdAt: string;
}

export type RoutineKind = 'morning' | 'night' | 'custom';

export interface RoutineStep {
  id: string;
  title: string;
  minutes: number; // duración estimada
}

/** Rutina (checklist de pasos) que se repite cada día. */
export interface Routine {
  id: number;
  profileId: number;
  title: string;
  kind: RoutineKind;
  icon: string;
  color: string;
  startTime: string | null; // HH:mm
  steps: RoutineStep[];
  weekdays: number[]; // vacío = todos los días
  remind: boolean;
  archived: boolean;
  createdAt: string;
}

/** Avance de una rutina en un día concreto. */
export interface RoutineLog {
  routineId: number;
  date: string;
  doneSteps: string[]; // ids de pasos completados
  completed: boolean;
}

// ---------- Dólar ----------

export type DollarCasa = 'oficial' | 'blue' | 'bolsa' | 'contadoconliqui' | 'tarjeta' | 'mayorista' | 'cripto';

/** Cotización de un día (se guarda una por casa y fecha; es información pública, no pertenece a un perfil). */
export interface DollarRate {
  casa: DollarCasa;
  date: string; // YYYY-MM-DD
  buy: number; // pesos con 2 decimales como número (ej. 1485.5)
  sell: number;
  updatedAt: string; // ISO
}

export type DollarAlertKind = 'above' | 'below' | 'change';

export interface DollarAlert {
  id: number;
  profileId: number;
  casa: DollarCasa;
  kind: DollarAlertKind;
  /** Umbral: pesos para above/below, porcentaje para change. */
  value: number;
  enabled: boolean;
  lastFiredAt: string | null;
  createdAt: string;
}

// ---------- Suscripciones ----------

export type SubscriptionCycle = 'weekly' | 'monthly' | 'yearly';

export interface Subscription {
  id: number;
  profileId: number;
  name: string;
  icon: string;
  color: string;
  amount: number; // centavos, en la moneda indicada
  currency: 'ARS' | 'USD';
  cycle: SubscriptionCycle;
  nextDate: string; // YYYY-MM-DD del próximo cobro
  remindDaysBefore: number | null;
  active: boolean;
  category: string;
  createdAt: string;
}

// ---------- Descubrir ----------

export interface DiscoverItem {
  id: number;
  profileId: number;
  topic: string;
  title: string;
  summary: string;
  url: string;
  source: string;
  imageUrl: string | null;
  publishedAt: string; // ISO
  saved: boolean;
  hidden: boolean;
  opened: boolean;
  fetchedAt: string;
}

// ---------- Amigo ----------

export type AssistantPersonality = 'warm' | 'direct' | 'fun';

export interface AssistantMessage {
  id: number;
  profileId: number;
  role: 'user' | 'assistant';
  text: string;
  /** Datos extra en JSON (tarjeta de confirmación, gráfico, etc.). */
  payload: Record<string, unknown> | null;
  createdAt: string;
}
