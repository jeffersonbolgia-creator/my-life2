import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHash, pbkdf2Sync, createHmac } from 'node:crypto';
import * as D from '../src/lib/dates';
import * as M from '../src/lib/money';
import * as C from '../src/lib/crypto';
import { normalizeText, matchesSearch, initials } from '../src/lib/text';

test('dates: suma de días y meses', () => {
  assert.equal(D.addDays('2026-02-27', 2), '2026-03-01');
  assert.equal(D.addDays('2024-02-28', 1), '2024-02-29');
  assert.equal(D.addMonths('2026-01-31', 1), '2026-02-28');
  assert.equal(D.addMonths('2024-01-31', 1), '2024-02-29');
  assert.equal(D.addMonths('2026-12-15', 1), '2027-01-15');
  assert.equal(D.addMonthsToKey('2026-01', -1), '2025-12');
});

test('dates: semanas, meses y diferencias', () => {
  assert.equal(D.startOfWeek('2026-11-04'), '2026-11-02'); // miércoles -> lunes
  assert.equal(D.startOfWeek('2026-11-08'), '2026-11-02'); // domingo -> lunes anterior
  assert.equal(D.endOfMonth('2026-02-10'), '2026-02-28');
  assert.equal(D.diffDays('2026-03-01', '2026-02-27'), 2);
  assert.equal(D.diffDays('2026-10-05', '2026-10-03'), 2); // cambio de horario no afecta
  assert.equal(D.rangeDays('2026-01-30', '2026-02-02').length, 4);
  const grid = D.monthGrid('2026-11');
  assert.equal(grid[0][0], '2026-10-26');
  assert.ok(grid.flat().includes('2026-11-30'));
  assert.equal(grid.length, 6);
});

test('dates: formatos en español', () => {
  assert.equal(D.formatLongDate('2026-11-04'), 'miércoles 4 de noviembre');
  const now = new Date(2026, 10, 4, 10);
  assert.equal(D.formatRelativeDay('2026-11-04', now), 'Hoy');
  assert.equal(D.formatRelativeDay('2026-11-05', now), 'Mañana');
  assert.equal(D.formatRelativeDay('2026-11-03', now), 'Ayer');
  assert.equal(D.formatRelativeDay('2026-11-06', now), 'Vie 6 nov');
  assert.equal(D.formatMonthYear('2026-11'), 'Noviembre 2026');
  assert.equal(D.ageFromBirth('2008-11-05', now), 17);
  assert.equal(D.ageFromBirth('2008-11-04', now), 18);
  assert.equal(D.parseUserDate('5/3/2010'), '2010-03-05');
  assert.equal(D.parseUserDate('31/02/2010'), null);
  assert.equal(D.greetingFor(new Date(2026, 1, 1, 8)), 'Buen día');
  assert.equal(D.greetingFor(new Date(2026, 1, 1, 22)), 'Buenas noches');
});

test('dates: horas', () => {
  assert.ok(D.isValidTime('07:30'));
  assert.ok(!D.isValidTime('24:00'));
  assert.equal(D.minutesToTime(-30), '23:30');
  const dt = D.combineDateTime('2026-11-04', '18:45');
  assert.equal(dt.getHours(), 18);
  assert.equal(dt.getMinutes(), 45);
});

test('money: formato de pesos argentinos', () => {
  assert.equal(M.formatMoney(600000), '$ 6.000');
  assert.equal(M.formatMoney(600050), '$ 6.000,50');
  assert.equal(M.formatMoney(123456789), '$ 1.234.567,89');
  assert.equal(M.formatMoney(-150000), '-$ 1.500');
  assert.equal(M.formatMoney(0), '$ 0');
  assert.equal(M.formatMoney(500, 'ARS', { sign: true }), '+$ 5');
});

test('money: interpretación de lo que escribe el usuario', () => {
  assert.equal(M.parseAmount('2.000'), 200000);
  assert.equal(M.parseAmount('2000'), 200000);
  assert.equal(M.parseAmount('2000,50'), 200050);
  assert.equal(M.parseAmount('2.000,5'), 200050);
  assert.equal(M.parseAmount('$ 1.234.567'), 123456700);
  assert.equal(M.parseAmount('2.5'), 250);
  assert.equal(M.parseAmount('0,99'), 99);
  assert.equal(M.parseAmount('abc'), null);
  assert.equal(M.parseAmount(''), null);
  assert.equal(M.parseAmount('1.23.4'), null);
  assert.equal(M.parseAmount('12,345'), 1234);
});

test('money: ejemplo del pedido (3 gaseosas a $2.000 = $6.000)', () => {
  const q = M.parseQuantity('3')!;
  const unit = M.parseAmount('2.000')!;
  const total = M.multiplyAmount(q, unit);
  assert.equal(total, 600000);
  assert.equal(M.formatMoney(total), '$ 6.000');
  assert.equal(M.multiplyAmount(M.parseQuantity('1,5')!, M.parseAmount('1.999')!), 299850);
  assert.equal(M.parseQuantity('0'), null);
  assert.equal(M.centsToInput(600050), '6000,50');
  assert.equal(M.parseAmount(M.centsToInput(123456)), 123456);
});

test('crypto: SHA-256 igual a la implementación de Node', () => {
  for (const s of ['', 'abc', 'MY LIFE – ñandú ✓', 'x'.repeat(1000)]) {
    assert.equal(C.toHex(C.sha256(C.utf8Encode(s))), createHash('sha256').update(s, 'utf8').digest('hex'));
  }
});

test('crypto: HMAC y PBKDF2 iguales a Node', () => {
  const key = C.utf8Encode('clave');
  const msg = C.utf8Encode('mensaje');
  assert.equal(C.toHex(C.hmacSha256(key, msg)), createHmac('sha256', 'clave').update('mensaje').digest('hex'));
  const salt = C.fromHex('00112233445566778899aabbccddeeff');
  assert.equal(
    C.toHex(C.pbkdf2Sha256(C.utf8Encode('1234'), salt, 1000, 32)),
    pbkdf2Sync('1234', Buffer.from(salt), 1000, 32, 'sha256').toString('hex'),
  );
});

test('crypto: hash y verificación de secretos', () => {
  const stored = C.hashSecret('4821', 'a1b2c3d4e5f60718293a4b5c6d7e8f90');
  assert.ok(stored.startsWith('pbkdf2$'));
  assert.ok(!stored.includes('4821'));
  assert.ok(C.verifySecret('4821', stored));
  assert.ok(!C.verifySecret('4822', stored));
  assert.ok(!C.verifySecret('4821', 'basura'));
});

test('texto: normalización y búsqueda', () => {
  assert.equal(normalizeText('  Ñandú   Pérez '), 'nandu perez');
  assert.ok(matchesSearch('Lista del súper', 'super lista'));
  assert.ok(!matchesSearch('Notas', 'compras'));
  assert.equal(initials('juan carlos pérez'), 'JP');
});
