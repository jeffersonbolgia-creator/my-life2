import { test, before } from 'node:test';
import assert from 'node:assert/strict';
import { setDb, migrate } from '../src/db/db';
import { openNodeDb } from './nodeDb';
import { configureSecurity, identifyByPin, checkRecoveryAnswer } from '../src/security/pin';
import { createProfileFromSetup, type SetupData } from '../src/services/createProfile';
import { eventsRepo, goalsRepo, habitsRepo, profilesRepo } from '../src/db/repos';

before(async () => {
  const db = openNodeDb();
  setDb(db);
  await migrate(db);
  const mem = new Map<string, string>();
  configureSecurity({ get: async (k) => mem.get(k) ?? null, set: async (k, v) => void mem.set(k, v), del: async (k) => void mem.delete(k) });
});

const base: SetupData = {
  name: 'Juan Pérez', birthDate: '2009-05-20', age: null,
  answers: { studiesAtSchool: true, wakeTime: '07:00', sleepTime: '23:00', interests: ['Música'] },
  schedules: [{ title: 'Colegio', days: [1, 2, 3, 4, 5], start: '07:30', end: '12:40' }],
  goals: ['Aprobar todas las materias', ' '], habits: ['Leer 20 minutos', 'Algo propio'],
  pin: '4821', pinLength: 4, securityQuestion: '¿Mascota?', securityAnswer: 'Firulais', biometrics: false,
  themeMode: 'dark', accent: 'violet', avatarColor: '#8B5CF6',
};

test('alta de perfil completa desde la bienvenida', async () => {
  const pid = await createProfileFromSetup(base, []);
  const p = await profilesRepo.get(pid);
  assert.equal(p!.name, 'Juan Pérez');
  assert.ok(p!.age! >= 16);
  assert.equal(p!.settings.notifications.dailySummary, true);
  assert.equal(p!.settings.notifications.dailySummaryTime, '07:15');
  const events = await eventsRepo.list(pid);
  assert.equal(events.length, 2);
  assert.ok(events.some((e) => e.type === 'schedule' && e.weekdays.length === 5 && e.startTime === '07:30'));
  assert.ok(events.some((e) => e.type === 'birthday' && e.recurrence === 'yearly'));
  assert.deepEqual((await goalsRepo.list(pid)).map((g) => g.title), ['Aprobar todas las materias']);
  const habits = await habitsRepo.list(pid);
  assert.equal(habits.length, 2);
  assert.equal(habits.find((h) => h.title === 'Leer 20 minutos')!.icon, 'BookOpen');
  assert.equal(await identifyByPin([pid], '4821'), pid);
  assert.ok(await checkRecoveryAnswer(pid, 'FIRULAIS'));
});

test('si el PIN es inválido no queda un perfil a medias', async () => {
  const before = (await profilesRepo.list()).length;
  await assert.rejects(() => createProfileFromSetup({ ...base, name: 'Tomás', pin: '12' }, []));
  assert.equal((await profilesRepo.list()).length, before);
});
